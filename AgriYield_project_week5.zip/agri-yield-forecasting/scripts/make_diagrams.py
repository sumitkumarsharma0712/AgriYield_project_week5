"""Conceptual diagrams used in the report (pipeline + validation design)."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = Path(__file__).resolve().parents[1] / "docs" / "figures"
OUT.mkdir(parents=True, exist_ok=True)
BLUE, ORANGE, GREEN, GREY, RED, SKY = "#0072B2", "#E69F00", "#009E73", "#6B7280", "#D55E00", "#56B4E9"


def pipeline():
    steps = [("1  Data\nacquisition", "weather · soil · crop\nmanagement · satellite", BLUE),
             ("2  Quality &\nleakage checks", "missing values · outliers\nforecast-origin timing", BLUE),
             ("3  Feature\nengineering", "lags · stress indices\nseasonality · ratios", GREEN),
             ("4  Chronological\nsplit", "development vs\nhidden test period", GREEN),
             ("5  Model training\n& tuning", "Ridge · RF · ET · GBM\nforward-chaining CV", ORANGE),
             ("6  Ensemble &\nselection", "champion chosen\non CV, not test", ORANGE),
             ("7  Evaluation &\nuncertainty", "baselines · intervals\nablation · drift", RED),
             ("8  Deployment &\nmonitoring", "retrain · PSI alerts\ndecision support", RED)]
    fig, ax = plt.subplots(figsize=(11, 4.6)); ax.axis("off"); ax.set_xlim(0, 4.4); ax.set_ylim(0, 2.2)
    for i, (t, s, c) in enumerate(steps):
        x, y = (i % 4) * 1.1 + 0.05, 1.25 if i < 4 else 0.15
        if i >= 4: x = (7 - i) * 1.1 + 0.05
        ax.add_patch(FancyBboxPatch((x, y), 0.95, 0.8, boxstyle="round,pad=0.02,rounding_size=0.05", fc=c, ec="none", alpha=.92))
        ax.text(x + .475, y + .55, t, ha="center", va="center", color="white", fontsize=10, fontweight="bold")
        ax.text(x + .475, y + .18, s, ha="center", va="center", color="white", fontsize=7.6)
    for i in range(7):
        if i < 3:
            a = ((i % 4) * 1.1 + 1.0, 1.65); b = ((i + 1) * 1.1 + 0.05, 1.65)
        elif i == 3:
            a = (3 * 1.1 + .525, 1.25); b = (3 * 1.1 + .525, .95)
        else:
            x0 = (7 - i) * 1.1 + 0.05; a = (x0, .55); b = (x0 - .1, .55)
        ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=14, color="#374151", lw=1.6))
    ax.add_patch(FancyArrowPatch((0.525, .15), (0.525, -.05), arrowstyle="-", color="none"))
    ax.text(2.2, 2.17, "AgriYield: end-to-end predictive modelling workflow", ha="center", fontsize=12, fontweight="bold")
    fig.savefig(OUT / "pipeline.png", dpi=200, bbox_inches="tight"); plt.close(fig)


def split():
    fig, ax = plt.subplots(figsize=(10, 3.4)); ax.set_xlim(2004, 2024); ax.set_ylim(-0.2, 5.4); ax.axis("off")
    ax.barh(4.6, 16, left=2005, height=.55, color=BLUE); ax.text(2013, 4.6, "Development set (2005–2020): training + tuning", ha="center", va="center", color="white", fontsize=9, fontweight="bold")
    ax.barh(4.6, 3, left=2021, height=.55, color=RED); ax.text(2022.5, 4.6, "Hidden test", ha="center", va="center", color="white", fontsize=9, fontweight="bold")
    for k, yv in enumerate([2017, 2018, 2019, 2020]):
        y = 3.5 - k * .8
        ax.barh(y, yv - 2005, left=2005, height=.5, color=SKY); ax.barh(y, 1, left=yv, height=.5, color=ORANGE)
        ax.text(2004.8, y, f"Fold {k+1}", ha="right", va="center", fontsize=8.5)
        ax.text(yv + 1.15, y, f"validate {yv}", va="center", fontsize=8)
    ax.barh(0.2, 16, left=2005, height=.5, color=GREEN); ax.barh(.2, 3, left=2021, height=.5, color=RED)
    ax.text(2013, .2, "Final refit on all development data", ha="center", va="center", color="white", fontsize=9, fontweight="bold")
    ax.text(2022.5, .2, "score once", ha="center", va="center", color="white", fontsize=9, fontweight="bold")
    ax.text(2014.5, 5.25, "Chronological split and forward-chaining validation (no look-ahead)", ha="center", fontsize=11, fontweight="bold")
    fig.savefig(OUT / "split_design.png", dpi=200, bbox_inches="tight"); plt.close(fig)


if __name__ == "__main__":
    pipeline(); split(); print("diagrams written to", OUT)
