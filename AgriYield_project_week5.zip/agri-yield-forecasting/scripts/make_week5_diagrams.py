"""Conceptual diagrams for the Week 5 report."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon

OUT = Path(__file__).resolve().parents[1] / "docs" / "figures"
BLUE, ORANGE, GREEN, GREY, RED, SKY = "#0072B2", "#E69F00", "#009E73", "#6B7280", "#D55E00", "#56B4E9"


def lifecycle():
    steps = [("1 Define", "audience, decisions,\nsuccess thresholds", BLUE), ("2 Measure", "metrics vs baselines\nwith confidence ranges", BLUE),
             ("3 Diagnose", "segments, bias, drift,\nrange reliability", GREEN), ("4 Visualise", "one message\nper chart", GREEN),
             ("5 Communicate", "answer-first summary\nand report card", ORANGE), ("6 Act & monitor", "recommendations,\nretrain triggers", RED)]
    fig, ax = plt.subplots(figsize=(11, 2.6)); ax.axis("off"); ax.set_xlim(0, 6.3); ax.set_ylim(0, 1.3)
    for i, (t, s, c) in enumerate(steps):
        x = i * 1.05 + .02
        ax.add_patch(FancyBboxPatch((x, .2), .92, .85, boxstyle="round,pad=0.02,rounding_size=0.05", fc=c, ec="none"))
        ax.text(x + .46, .83, t, ha="center", va="center", color="white", fontsize=10.5, fontweight="bold")
        ax.text(x + .46, .45, s, ha="center", va="center", color="white", fontsize=8)
        if i < 5: ax.add_patch(FancyArrowPatch((x + .93, .62), (x + 1.06, .62), arrowstyle="-|>", mutation_scale=13, color="#374151", lw=1.5))
    ax.add_patch(FancyArrowPatch((6.2, .12), (.1, .12), arrowstyle="-|>", mutation_scale=12, color=GREY, lw=1.2, connectionstyle="arc3,rad=0"))
    ax.text(3.15, .02, "feedback loop: every season's actual outcomes update the evaluation", ha="center", fontsize=8.5, color=GREY, style="italic")
    fig.savefig(OUT / "eval_lifecycle.png", dpi=200, bbox_inches="tight"); plt.close(fig)


def pyramid():
    fig, ax = plt.subplots(figsize=(9, 4.4)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 5.6)
    layers = [(RED, "Layer 1: Executive one-pager", "Verdict, five numbers, three actions", "1 page  |  leadership, business heads", 3.45, 4.4),
              (ORANGE, "Layer 2: Stakeholder briefing", "Report card, 6-8 charts, plain-language findings", "5-8 pages  |  managers, planners, field teams", 1.95, 6.6),
              (BLUE, "Layer 3: Technical appendix", "All metrics, confidence ranges, diagnostics, code and data lineage", "Full detail  |  data science, audit", 0.45, 9.4)]
    for col, t, s1, s2, y, w in layers:
        ax.add_patch(FancyBboxPatch((5 - w / 2, y), w, 1.35, boxstyle="round,pad=0.02,rounding_size=0.12", fc=col, ec="none"))
        ax.text(5, y + 1.0, t, ha="center", va="center", color="white", fontsize=12, fontweight="bold")
        ax.text(5, y + .62, s1, ha="center", va="center", color="white", fontsize=9)
        ax.text(5, y + .3, s2, ha="center", va="center", color="white", fontsize=9, style="italic")
    ax.text(0.05, 5.4, "Reporting layers: the same facts at three levels of detail", fontsize=12.5, fontweight="bold", va="center")
    fig.savefig(OUT / "reporting_pyramid.png", dpi=200, bbox_inches="tight"); plt.close(fig)


if __name__ == "__main__":
    lifecycle(); pyramid(); print("ok")
