"""Unit tests for the evaluation/reporting module."""
import sys, unittest
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from agrieval import metrics as M
from agrieval import scorecard as S
from agrieval.config import EvalPolicy


class EvaluationTests(unittest.TestCase):
    def test_perfect_forecast(self):
        y = np.array([10., 20., 30.])
        m = M.point_metrics(y, y)
        self.assertEqual(m["RMSE"], 0); self.assertEqual(m["WithinTol"], 1.0); self.assertAlmostEqual(m["R2"], 1.0)

    def test_bias_sign_and_pct(self):
        y = np.array([100., 100.]); p = np.array([90., 90.])
        m = M.point_metrics(y, p)
        self.assertAlmostEqual(m["Bias"], -10); self.assertAlmostEqual(m["BiasPct"], -10)

    def test_within_tolerance(self):
        m = M.point_metrics(np.array([100, 100, 100, 100.]), np.array([105, 95, 120, 80.]), 10)
        self.assertAlmostEqual(m["WithinTol"], 0.5)

    def test_wape_vs_mape_weighting(self):
        y = np.array([1., 100.]); p = np.array([2., 100.])
        m = M.point_metrics(y, p)
        self.assertGreater(m["MAPE"], m["WAPE"])           # small items dominate MAPE, not WAPE

    def test_mase_below_one_beats_naive(self):
        y = np.array([10., 12., 14.]); naive = np.array([8., 8., 8.])
        self.assertLess(M.mase(y, y + .5, naive), 1)

    def test_asymmetric_cost(self):
        y = np.array([10., 10.])
        self.assertGreater(M.asymmetric_cost(y, y - 1, 2, 1), M.asymmetric_cost(y, y + 1, 2, 1))

    def test_detection_metrics(self):
        a = np.array([1, 1, 0, 0, 1], bool); p = np.array([1, 0, 1, 0, 1], bool)
        d = M.detection_metrics(a, p)
        self.assertEqual((d["TP"], d["FP"], d["FN"], d["TN"]), (2, 1, 1, 1))
        self.assertAlmostEqual(d["Recall"], 2 / 3)

    def test_interval_metrics(self):
        d = M.interval_metrics(np.array([5., 15.]), np.array([0., 0.]), np.array([10., 10.]))
        self.assertAlmostEqual(d["Coverage"], 0.5)
        self.assertGreater(d["IntervalScore"], d["MeanWidth"])

    def test_cluster_bootstrap_contains_estimate(self):
        rng = np.random.default_rng(0)
        df = pd.DataFrame({"g": np.repeat(range(12), 5), "y_true": rng.normal(10, 1, 60)})
        df["y_pred"] = df.y_true + rng.normal(0, 1, 60)
        f = lambda d: np.sqrt(np.mean((d.y_pred - d.y_true) ** 2))
        lo, hi, _ = M.cluster_bootstrap(df, f, "g", n_boot=300)
        self.assertLess(lo, f(df)); self.assertGreater(hi, f(df))

    def test_scorecard_status_rules(self):
        pol = EvalPolicy()
        good = dict(MAPE=5, Skill=.5, WithinTol=.8, BiasPct=1, Coverage=.9, Recall=.8)
        self.assertEqual(S.overall_status(S.build_scorecard(good, pol)), "GREEN")
        one_red = {**good, "BiasPct": -9}
        self.assertEqual(S.overall_status(S.build_scorecard(one_red, pol)), "AMBER")
        core_red = {**good, "MAPE": 30}
        self.assertEqual(S.overall_status(S.build_scorecard(core_red, pol)), "RED")


if __name__ == "__main__":
    unittest.main()
