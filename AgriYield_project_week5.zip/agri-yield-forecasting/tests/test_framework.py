"""Unit tests (stdlib unittest; also discovered by pytest)."""
import sys, unittest
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from agriyield.config import CROP_YIELD, DAIRY_MILK
from agriyield.data_generator import generate_crop_data, generate_dairy_data
from agriyield.evaluate import conformal_interval, psi, regression_metrics
from agriyield.features import build_features
from agriyield.models import ExpandingWindowSplit


class FrameworkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.crop = generate_crop_data()

    def test_crop_schema(self):
        need = CROP_YIELD.raw_features + [CROP_YIELD.target]
        self.assertEqual([c for c in need if c not in self.crop.columns], [])

    def test_dairy_schema(self):
        d = generate_dairy_data()
        need = DAIRY_MILK.raw_features + [DAIRY_MILK.target]
        self.assertEqual([c for c in need if c not in d.columns], [])

    def test_lag_features_do_not_leak(self):
        df, _ = build_features(self.crop, CROP_YIELD)
        one = df[(df.district == "Nagpur") & (df.crop == "Cotton")].sort_values("year")
        self.assertTrue(np.allclose(one["yield_q_ha_lag1"].iloc[1:].values, one["yield_q_ha"].iloc[:-1].values))
        self.assertTrue(np.isnan(one["yield_q_ha_lag1"].iloc[0]))
        self.assertAlmostEqual(one["yield_q_ha_roll3"].iloc[3], one["yield_q_ha"].iloc[0:3].mean())

    def test_expanding_window_has_no_look_ahead(self):
        t = self.crop["year"].values
        cv = ExpandingWindowSplit(t, n_folds=4, block=1, dev_mask=t <= 2020)
        folds = list(cv.split())
        self.assertEqual(len(folds), 4)
        for tr, va in folds:
            self.assertLess(t[tr].max(), t[va].min())
            self.assertLessEqual(t[va].max(), 2020)

    def test_metrics(self):
        y = np.array([1., 2., 3.])
        self.assertEqual(regression_metrics(y, y)["RMSE"], 0)
        self.assertAlmostEqual(regression_metrics(y, y + 1)["Bias"], 1.0)

    def test_conformal_coverage(self):
        rng = np.random.default_rng(0)
        lo, hi, _ = conformal_interval(rng.normal(0, 1, 2000), np.zeros(5000), 0.1)
        cov = np.mean((rng.normal(0, 1, 5000) >= lo) & (rng.normal(0, 1, 5000) <= hi))
        self.assertTrue(0.87 < cov < 0.93)

    def test_psi(self):
        rng = np.random.default_rng(1)
        a = pd.Series(rng.normal(0, 1, 2000))
        self.assertLess(psi(a, pd.Series(rng.normal(0, 1, 2000))), 0.1)
        self.assertGreater(psi(a, pd.Series(rng.normal(2, 1, 2000))), 0.25)


if __name__ == "__main__":
    unittest.main()
