# Executive summary: District-level seasonal crop yield forecasting

**Overall verdict: AMBER. The model is usable for planning, provided the safeguards listed under Recommendations are put in place.**

## What we measured
The model forecast 210 outcomes that it had never seen (year 2021 to 2023). Its results were compared with the simple rule 'next value = last value'.

## Headline findings
- A typical forecast is **7.9% away** from the actual value (average miss 1.38 quintal/ha).
- **55% fewer errors** than the simple rule (95% confidence range 44% to 65%).
- **69%** of forecasts landed within +/-10% of the real value.
- The model under-forecasts by 6.4% on average.
- The stated 90% range contained the real value 86% of the time.
- Using the agreed cost weights (a shortfall costs 2x a surplus), planning with the model costs **50% less** than planning with the simple rule.
- It flagged **82%** of the genuine shortfall cases in advance; 74% of its warnings were correct.
- Most accurate for **Tur** (6.5% error); least accurate for **Wheat** (11.1% error).

## Scorecard
| Question | Result | Status |
|---|---|---|
| How big is a typical miss? | 7.9% (MAPE) | GREEN |
| Is it better than the simple rule? | 55% fewer errors | GREEN |
| How often is it usable (within +/-10%)? | 69% of forecasts | GREEN |
| Does it lean high or low? | -6.4% bias | RED |
| Can we trust the range? | 86% inside the 90% range | AMBER |
| Does it warn us of bad seasons? | 82% of shortfalls caught | GREEN |

## Recommendations
1. Correct the systematic under-forecast (-6.4%): add a trend-adjusted target or retrain every season on the newest data, then re-check the bias.
2. Recalibrate the 90% range (currently covers 86%) using the most recent seasons' errors so that planners can rely on it.
3. The forecast range is uneven across crops (Rice: 64% covered vs Cotton: 100%): switch to ranges calibrated separately per crop (or proportional to the forecast).
4. Investigate the weakest segment (crop: Wheat, 11.1% error): collect better inputs or fit a segment-specific model.
5. Validate on real field data and extend the test window to at least five seasons before committing budget decisions.

## Caveats
- Results come from a limited number of test periods; confidence ranges are shown for this reason.
- Forecast quality describes association, not cause: the model should support, not replace, local expertise.
- Cost figures use relative weights (shortfall = 2x surplus) that must be confirmed with the business.