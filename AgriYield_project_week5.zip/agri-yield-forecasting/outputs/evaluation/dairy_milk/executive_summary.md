# Executive summary: Farm-level monthly milk yield forecasting

**Overall verdict: GREEN. The model is ready for operational use.**

## What we measured
The model forecast 480 outcomes that it had never seen (month_idx 49 to 60). Its results were compared with the simple rule 'next value = last value'.

## Headline findings
- A typical forecast is **5.0% away** from the actual value (average miss 0.50 litres/cow/day).
- **62% fewer errors** than the simple rule (95% confidence range 58% to 65%).
- **89%** of forecasts landed within +/-10% of the real value.
- The model under-forecasts by 0.1% on average.
- The stated 90% range contained the real value 90% of the time.
- Using the agreed cost weights (a shortfall costs 2x a surplus), planning with the model costs **60% less** than planning with the simple rule.
- It flagged **70%** of the genuine shortfall cases in advance; 84% of its warnings were correct.
- Most accurate for **Jersey_cross** (4.4% error); least accurate for **Gir** (7.0% error).

## Scorecard
| Question | Result | Status |
|---|---|---|
| How big is a typical miss? | 5.0% (MAPE) | GREEN |
| Is it better than the simple rule? | 62% fewer errors | GREEN |
| How often is it usable (within +/-10%)? | 89% of forecasts | GREEN |
| Does it lean high or low? | -0.1% bias | GREEN |
| Can we trust the range? | 90% inside the 90% range | GREEN |
| Does it warn us of bad seasons? | 70% of shortfalls caught | GREEN |

## Recommendations
1. Validate on real field data and extend the test window to at least five seasons before committing budget decisions.

## Caveats
- Results come from a limited number of test periods; confidence ranges are shown for this reason.
- Forecast quality describes association, not cause: the model should support, not replace, local expertise.
- Cost figures use relative weights (shortfall = 2x surplus) that must be confirmed with the business.