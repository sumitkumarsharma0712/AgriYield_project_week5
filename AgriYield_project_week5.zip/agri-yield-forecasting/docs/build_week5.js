const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, Header, Footer,
  AlignmentType, LevelFormat, HeadingLevel, BorderStyle, WidthType, ShadingType, PageNumber, PageBreak,
  TabStopType, TabStopPosition,
} = require("docx");

const D = JSON.parse(fs.readFileSync(path.join(__dirname, "week5_data.json"), "utf8"));
const OUT = path.join(__dirname, "..", "outputs");
const FIG = path.join(__dirname, "figures");
const PRIMARY = "0B4F6C", LIGHT = "E8F1F5", ACCENT = "D55E00", GREY = "5B6770", BORDER = "BFC9D0", ZEBRA = "F5F8FA";
const PAGE_W = 11906, PAGE_H = 16838, MARGIN = 1247, CW = PAGE_W - 2 * MARGIN; // 9412 content width (DXA)

let figN = 0, tabN = 0;

// ---------- helpers ----------
const run = (t, o = {}) => new TextRun({ text: t, ...o });
function rich(text, base = {}) {          // **bold** inline markup
  return text.split(/(\*\*[^*]+\*\*)/g).filter(Boolean).map(s =>
    s.startsWith("**") ? run(s.slice(2, -2), { ...base, bold: true }) : run(s, base));
}
const P = (text, o = {}) => new Paragraph({ children: rich(text, o.run || {}), spacing: { after: 120, line: 288 }, alignment: o.align || AlignmentType.JUSTIFIED, ...o.para });
const H1 = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [run(t)] });
const H1p = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [run(t)], pageBreakBefore: true });
const H1n = t => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [run(t)] });
const H2 = t => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [run(t)] });
const H3 = t => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [run(t)] });
const B = (t, lvl = 0) => new Paragraph({ numbering: { reference: "bullets", level: lvl }, children: rich(t), spacing: { after: 70, line: 276 } });
const N = (t, ref = "nums") => new Paragraph({ numbering: { reference: ref, level: 0 }, children: rich(t), spacing: { after: 70, line: 276 } });
const spacer = (n = 120) => new Paragraph({ children: [], spacing: { after: n } });

const border = { style: BorderStyle.SINGLE, size: 4, color: BORDER };
const borders = { top: border, bottom: border, left: border, right: border };

function cell(text, w, o = {}) {
  const paras = String(text).split("\n").map(line => new Paragraph({
    alignment: o.align || AlignmentType.LEFT, spacing: { after: 30, line: 252 },
    children: rich(line, { size: o.size || 18, color: o.color, bold: o.bold }),
  }));
  return new TableCell({
    width: { size: w, type: WidthType.DXA }, borders, verticalAlign: "center",
    shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR, color: "auto" } : undefined,
    margins: { top: 60, bottom: 60, left: 90, right: 90 }, children: paras, columnSpan: o.span,
  });
}
function table(headers, rows, widths, o = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const al = o.align || widths.map(() => AlignmentType.LEFT);
  const hdr = new TableRow({ tableHeader: true, cantSplit: true, children: headers.map((h, i) => cell(h, widths[i], { fill: PRIMARY, color: "FFFFFF", bold: true, align: al[i] === AlignmentType.LEFT ? AlignmentType.LEFT : AlignmentType.CENTER, size: o.size })) });
  const body = rows.map((r, ri) => new TableRow({
    cantSplit: true,
    children: r.map((c, i) => cell(c, widths[i], { align: al[i], fill: (o.hi && o.hi.includes(ri)) ? "FFF2CC" : (ri % 2 ? ZEBRA : undefined), bold: (i === 0 && o.boldFirst), size: o.size })),
  }));
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths, rows: [hdr, ...body] });
}
const caption = (kind, text) => {
  const n = kind === "Figure" ? ++figN : ++tabN;
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 200 }, keepNext: kind === "Table" ? false : false,
    children: [run(`${kind} ${n}. `, { bold: true, size: 18, color: PRIMARY }), run(text, { italics: true, size: 18, color: GREY })] });
};
const tcap = text => { const n = ++tabN; return new Paragraph({ spacing: { before: 160, after: 80 }, keepNext: true, children: [run(`Table ${n}. `, { bold: true, size: 18, color: PRIMARY }), run(text, { italics: true, size: 18, color: GREY })] }); };
function pngSize(p) { const b = fs.readFileSync(p); return [b.readUInt32BE(16), b.readUInt32BE(20)]; }
function fig(file, widthPx, cap, dir = FIG) {
  const p = path.join(dir, file); const [w, h] = pngSize(p);
  return [new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 40 },
    children: [new ImageRun({ type: "png", data: fs.readFileSync(p), transformation: { width: widthPx, height: Math.round(widthPx * h / w) },
      altText: { title: cap, description: cap, name: file } })] }), caption("Figure", cap)];
}
const _unused1 = (f, w, c) => fig(f, w, c, path.join(OUT, "crop_yield", "figures"));
const _unused2 = (f, w, c) => fig(f, w, c, path.join(OUT, "dairy_milk", "figures"));

function callout(title, lines, fill = LIGHT, bar = PRIMARY) {
  const nb = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
  return new Table({
    width: { size: CW, type: WidthType.DXA }, columnWidths: [CW],
    rows: [new TableRow({ cantSplit: true, children: [new TableCell({
      width: { size: CW, type: WidthType.DXA }, shading: { fill, type: ShadingType.CLEAR, color: "auto" },
      borders: { top: nb, bottom: nb, right: nb, left: { style: BorderStyle.SINGLE, size: 24, color: bar } },
      margins: { top: 120, bottom: 120, left: 200, right: 160 },
      children: [new Paragraph({ spacing: { after: 80 }, children: [run(title, { bold: true, color: bar, size: 22 })] }),
        ...lines.map(l => new Paragraph({ spacing: { after: 60, line: 276 }, children: rich(l, { size: 20 }) }))],
    })] })],
  });
}
const f2 = (x, d = 2) => Number(x).toFixed(d);
const R = AlignmentType.RIGHT, L = AlignmentType.LEFT, C = AlignmentType.CENTER;



const evFig = (scn, f, w, c) => fig(f, w, c, path.join(OUT, "evaluation", scn, "figures"));
const cy = D.crop_yield, dm = D.dairy_milk, cM = cy.model, dM = dm.model;
const pct = (x, d = 0) => (x * 100).toFixed(d) + "%";
const numRefs = ["nums", "n1", "n2", "n3", "n4", "n5"];
const T0 = cy.table, DT0 = dm.table;                 // [name, RMSE, MAE, MAPE, WAPE, R2, BiasPct, WithinTol, MASE, Cost, Skill]
const mr = t => t.map(r => [r[0], f2(r[1]), f2(r[2]), f2(r[3], 1), f2(r[4], 1), f2(r[5], 3), (r[6] >= 0 ? "+" : "") + f2(r[6], 1), pct(r[7]), f2(r[8]), f2(r[9]), pct(r[10])]);
const mh = ["Forecast", "RMSE", "MAE", "MAPE %", "WAPE %", "R²", "Bias %", "Within ±10%", "MASE", "Cost", "Skill"];
const mw = [2300, 640, 640, 740, 740, 660, 700, 880, 640, 640, 672];
const mal = [L, R, R, R, R, R, R, R, R, R, R];
const ci = cy.ci, dci = dm.ci;
const DET = cy.detection_model, DETn = cy.detection_naive, dDET = dm.detection_model, dDETn = dm.detection_naive;

// ---------- cover ----------
const cover = [
  spacer(1400),
  new Paragraph({ children: [run("WEEK 5 TASK  |  FINAL SUBMISSION", { bold: true, size: 22, color: ACCENT, characterSpacing: 40 })], spacing: { after: 240 } }),
  new Paragraph({ children: [run("Model Evaluation and Reporting Strategy", { bold: true, size: 64, color: PRIMARY })], spacing: { after: 120 } }),
  new Paragraph({ children: [run("A framework for assessing predictive models and communicating results to agribusiness stakeholders", { size: 32, color: "33414A" })], spacing: { after: 360 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: ACCENT, space: 12 } } }),
  new Paragraph({ children: [run("Performance metrics, stakeholder-friendly visualisation, executive reporting, limitations and refinement, demonstrated on the AgriYield crop-yield and dairy-milk forecasting models.", { size: 24, color: GREY, italics: true })], spacing: { before: 240, after: 1500 } }),
  new Paragraph({ children: [run("Prepared by", { size: 20, color: GREY })] }),
  new Paragraph({ children: [run("Sumit Kumar Sharma", { bold: true, size: 36, color: PRIMARY })] }),
  new Paragraph({ children: [run("Junior Data Scientist Intern  |  Nagpur, Maharashtra, India", { size: 24 })], spacing: { after: 300 } }),
  new Paragraph({ children: [run("Submission date: 26 October 2026", { size: 22, color: GREY })] }),
  new Paragraph({ children: [run("Code: agri-yield-forecasting (package agrieval, Python 3)", { size: 22, color: GREY })] }),
];
const toc = [["1", "Executive Summary"], ["2", "Purpose, Audience and Evaluation Principles"], ["3", "Model and Evaluation Design"], ["4", "Performance Metrics"],
  ["5", "Visualisation Plan for Non-Expert Stakeholders"], ["6", "Results of the Demonstration Evaluation"], ["7", "Reporting Strategy and Executive Summary"],
  ["8", "Recommendations for Improving the Model"], ["9", "Limitations and Further Refinement"], ["10", "Monitoring and Governance"], ["11", "Conclusion"], ["", "References"],
  ["A", "Appendix A: Plain-Language Glossary"], ["B", "Appendix B: Implementation and Reproduction"]];
const tocBlock = [
  new Paragraph({ children: [run("Contents", { bold: true, size: 36, color: PRIMARY })], spacing: { after: 240 }, pageBreakBefore: true }),
  ...toc.map(([n, t]) => new Paragraph({ spacing: { after: 110 }, tabStops: [{ type: TabStopType.LEFT, position: 700 }], children: [run(n, { bold: true, color: ACCENT, size: 24 }), run("\t" + t, { size: 24 })] })),
];

// ---------- 1 ----------
const s1 = [
  H1n("1. Executive Summary"),
  P("A forecasting model is only as valuable as the decisions it improves. Between a model that is statistically accurate and a model that a procurement manager, a district officer or a chief executive is willing to act on lies a gap that evaluation and reporting must close. This document sets out a complete strategy to close that gap: **how to measure a predictive model properly, how to show the findings so that non-specialists can read them correctly, and how to report conclusions and next steps to decision-makers.**"),
  P("The strategy is demonstrated on a real, working implementation: the AgriYield crop-yield forecasting model built in Week 4, plus a second model for dairy milk output. Both were evaluated with the new agrieval software package delivered with this report, so every number and chart below is reproducible."),
  callout("The strategy in five principles", [
    "**1. Answer first.** Every report opens with a verdict and a traffic-light report card, then supports it with evidence.",
    "**2. Always compare with a simple alternative.** Accuracy has meaning only relative to what the business could do without the model.",
    "**3. Measure what the decision needs.** Core error metrics are complemented by within-tolerance share, planning cost, shortfall early-warning and range reliability.",
    "**4. Show the uncertainty.** Metrics carry confidence ranges, and forecasts carry prediction ranges whose real coverage is checked.",
    "**5. Be candid and actionable.** Weaknesses are reported with evidence and turned into prioritised recommendations.",
  ]),
  spacer(140),
  callout(`Demonstration result: crop-yield model is ${cy.status} (usable with safeguards)`, [
    `Across ${cy.n} hidden test forecasts a typical forecast is **${f2(cM.MAPE, 1)}% away** from the actual yield, with **${pct(cM.Skill)} fewer errors** than the "same as last year" rule (95% range ${pct(ci.Skill[0])} to ${pct(ci.Skill[1])}). ${pct(cM.WithinTol)} of forecasts are within ±10%, and ${pct(DET.Recall)} of genuine shortfall seasons were warned of in advance.`,
    `Two weaknesses were found and are explained in plain language: the model **leans low by ${f2(Math.abs(cM.BiasPct), 1)}%**, and its 90% range **captured only ${pct(cM.Coverage)}** of outcomes (rice 64%, wheat 74%). Section 8 turns these into concrete fixes.`,
    `The same evaluation applied unchanged to the dairy model returned **${dm.status}**: ${f2(dM.MAPE, 1)}% typical error, ${pct(dM.Skill)} fewer errors than the simple rule, ${pct(dM.Coverage)} range coverage.`,
  ], "FFF2E0", ACCENT),
  spacer(100),
  P("**Disclosure.** The data are simulated with documented agronomic relationships (see Week 4). The evaluation methodology, the software and the way results are communicated are fully valid; the specific accuracy values should be re-established on real data before any operational decision."),
  ...evFig("crop_yield", "01_scorecard.png", 560, "Report card for the crop-yield model: six plain-language questions, each with a result and a status (colour and text)."),
];

// ---------- 2 ----------
const s2 = [
  H1p("2. Purpose, Audience and Evaluation Principles"),
  H2("2.1 Why accuracy alone is not enough"),
  P("A single score such as R² = 0.94 sounds impressive, but it cannot tell a manager whether to place an order. Three models with identical RMSE can behave very differently: one may consistently under-forecast, which leaves warehouses empty; another may be excellent on average but fail in drought years, which are the very seasons that matter; a third may be accurate but give prediction ranges that cannot be trusted. Evaluation must therefore answer a set of questions rather than report one number:"),
  B("**How big are the errors,** in units and in percent, and are they better than a simple alternative?"),
  B("**Are the errors systematic?** Does the model lean high or low, or fail for particular crops, regions or years?"),
  B("**Can the stated uncertainty be trusted?**"),
  B("**Does it help the actual decision?** For example, does it give early warning of a bad season, and does planning with it cost less?"),
  B("**How sure are we about these answers,** given a limited test period?"),
  H2("2.2 Stakeholders and what each needs"),
  table(["Stakeholder", "Decision they make", "What they need from the evaluation", "Best format"], [
    ["Executives and business heads", "Invest in, scale or stop the model", "Verdict, business value, key risks, ask", "One-page summary and report card"],
    ["Procurement and supply-chain planners", "How much to buy, store and move", "Typical error in units, bias direction, usable range, shortfall warning", "Report card, range chart, plain-language note"],
    ["Field and extension officers", "Which districts or crops to prioritise", "Where forecasts are strong or weak; early-warning list", "Segment charts, hardest-case examples"],
    ["Credit and insurance teams", "Pricing and trigger of cover", "Range reliability, behaviour in bad years", "Range and shortfall charts"],
    ["Data science and audit", "Trust, reproduce and improve", "Full metrics, confidence intervals, diagnostics, code", "Technical appendix, notebooks, CSV outputs"],
  ], [2000, 2000, 3000, 2412], { boldFirst: true, size: 17 }),
  tcap("Stakeholder map for evaluation reporting."),
  H2("2.3 Guiding principles"),
  N("**Evaluate on data the model has never seen,** in chronological order, exactly as it will be used.", "nums"),
  N("**Compare against baselines,** such as 'same as last season' and 'average of the last three seasons'.", "nums"),
  N("**Choose metrics from the decision backwards,** not from habit.", "nums"),
  N("**Quantify uncertainty twice:** uncertainty of the forecast (prediction range) and uncertainty of the evaluation (confidence range on each metric).", "nums"),
  N("**Slice the results** by crop, region and time to expose weaknesses hidden by averages.", "nums"),
  N("**Communicate in the audience's language,** with one message per chart and an explicit recommendation.", "nums"),
  N("**Make it repeatable:** one command regenerates all numbers and charts, so every season's report is consistent.", "nums"),
  ...fig("eval_lifecycle.png", 600, "The evaluation lifecycle: from defining success to acting and monitoring, with a feedback loop."),
];

// ---------- 3 ----------
const s3 = [
  H1p("3. Model and Evaluation Design"),
  H2("3.1 The model under evaluation"),
  P(`The evaluation is demonstrated on the AgriYield ensemble from Week 4 (Gradient Boosting averaged with Extra Trees). For every district and crop it forecasts the next season's yield in quintal per hectare from weather, soil, management, satellite and yield-history features. It was trained on 2005-2020 and has never seen 2021-2023. A second model forecasts monthly milk yield per cow for ${dm.n / 12} farms; it is used to show that the same evaluation transfers to another problem.`),
  H2("3.2 Evaluation data and units"),
  table(["Item", "Crop-yield model", "Dairy model"], [
    ["Hidden test period", "2021-2023", "Months 49-60"],
    ["Number of test forecasts", String(cy.n), String(dm.n)],
    ["Unit of analysis", "One district-crop-year", "One farm-month"],
    ["Cluster for resampling", "District (14 clusters)", "Farm (40 clusters)"],
    ["Segment for slicing", "Crop (5)", "Breed (4)"],
    ["Baselines", "Same as last season; 3-season average", "Same as last month; 3-month average"],
  ], [3000, 3200, 3212], { boldFirst: true }),
  tcap("Evaluation design for the two demonstrations."),
  H2("3.3 Rules that protect the credibility of results"),
  B("**No peeking:** model selection and tuning use only the development years; the test period is scored once."),
  B("**No look-ahead:** all inputs, including lagged yields, are known at the forecast origin."),
  B("**Same rows for everyone:** model and baselines are scored on identical forecasts."),
  B("**Clusters, not rows:** observations from one district are correlated, so resampling for confidence ranges is done by district (or farm)."),
  B("**Pre-agreed thresholds:** green, amber and red limits are written down in a policy file before results are seen (Section 4.7)."),
];

// ---------- 4 ----------
const s4 = [
  H1p("4. Performance Metrics"),
  P("Metrics are grouped into four families that answer different questions: error size, decision value, uncertainty and statistical confidence. For each metric the report gives a definition, a plain-language reading, and its strengths and pitfalls in an agribusiness context."),
  H2("4.1 Core error metrics"),
  tcap("Core error metrics (e is forecast minus actual; y is the actual value; n is the number of forecasts)."),
  table(["Metric", "Definition", "Plain-language meaning", "Strengths and pitfalls"], [
    ["RMSE (root mean squared error)", "sqrt( mean(e²) )", "A 'typical' error in the original units, with large misses weighted more heavily", "Highlights costly big misses (droughts); sensitive to outliers; units differ across crops so not comparable between crops"],
    ["MAE (mean absolute error)", "mean( |e| )", "The average size of a miss in the original units", "Easy to explain to non-experts; treats all misses equally. RMSE well above MAE signals occasional large misses"],
    ["MAPE (mean absolute percentage error)", "mean( |e| / y ) x 100", "The average miss as a percentage of the actual value", "Comparable across crops and regions; unstable when actual values are near zero; over-weights small-yield cases"],
    ["WAPE (weighted absolute percentage error)", "sum|e| / sum y x 100", "Total error as a percentage of total production", "Matches volume-based business planning; robust to small items"],
    ["R² (coefficient of determination)", "1 - sum(e²) / sum((y - mean y)²)", "Share of the variation in outcomes that the forecasts explain", "Intuitive, but inflated when very different crops are pooled; says nothing about bias; never use alone"],
    ["Bias and bias %", "mean(e); mean(e) / mean(y) x 100", "Does the model lean high (+) or low (-), and by how much?", "Reveals systematic over- or under-forecasting that averages of absolute errors hide"],
    ["MASE (mean absolute scaled error)", "MAE(model) / MAE(naive)", "Error relative to the simple 'same as last period' rule; below 1 beats it", "Scale-free and honest about added value; needs a sensible naive rule (Hyndman and Koehler, 2006)"],
  ], [1900, 1900, 2700, 2912], { boldFirst: true, size: 16 }),
  P(`**Worked reading.** For the crop model RMSE is ${f2(T0[0][1])} q/ha and MAE is ${f2(T0[0][2])} q/ha. The ratio RMSE/MAE = ${f2(T0[0][1] / T0[0][2])} is above the value of about 1.25 expected for evenly spread (normally distributed) errors, which tells us a minority of forecasts miss by a lot. That is why the evaluation also reports the 90th-percentile miss (${f2(cM.P90_AbsErrPct, 1)}%): one forecast in ten is off by more than this.`),
  H2("4.2 Decision-oriented metrics"),
  tcap("Metrics linked directly to business decisions."),
  table(["Metric", "Definition", "Decision it informs"], [
    ["Within-tolerance share", "Share of forecasts within ±10% of actual (tolerance agreed with users)", "'How often can I plan with this number as it is?'"],
    ["Skill score vs simple rule", "1 - RMSE(model) / RMSE(last-period rule)", "'Is the model worth its cost compared with a spreadsheet rule?'"],
    ["Asymmetric planning cost", "mean( 2 x shortfall + 1 x surplus ) per unit, weights configurable", "Stock-outs usually cost more than surplus; ranks models by money rather than symmetry"],
    ["Shortfall early warning", "Event: actual below 85% of the 3-season average. Precision = correct warnings / all warnings; recall = warnings / real shortfalls", "Drought preparedness, crop-insurance triggers, relief planning"],
    ["Rank agreement (Spearman)", "Correlation of forecast and actual ranking of entities within each period", "Prioritising districts or farms for support, even if exact values are off"],
  ], [2200, 4000, 3212], { boldFirst: true, size: 17 }),
  P("Asymmetric cost deserves emphasis. If a shortage costs twice as much as a surplus, a model that errs slightly high can be better for the business than one that errs slightly low, even with identical RMSE. The weights (2:1 here) are an assumption that the business must confirm."),
  H2("4.3 Uncertainty metrics"),
  tcap("Metrics for prediction ranges and calibration."),
  table(["Metric", "Definition", "Plain-language reading"], [
    ["Coverage", "Share of actual outcomes inside the stated 90% range", "A trustworthy range holds about 9 out of 10 outcomes"],
    ["Mean width", "Average length of the range", "Narrow is better only if coverage is kept; wide ranges are safe but unhelpful"],
    ["Interval score (Gneiting and Raftery, 2007)", "Width plus a penalty for each miss; lower is better", "One number that rewards narrow, correct ranges"],
    ["Calibration slope and intercept", "Regression of actual on forecast; ideal slope 1, intercept 0", "Are forecasts too timid (slope above 1) or too extreme (below 1)?"],
    ["Coverage by segment", "Coverage computed separately for each crop, region or year", "Exposes ranges that work on average but fail for some groups"],
  ], [2400, 3700, 3312], { boldFirst: true, size: 17 }),
  H2("4.4 Statistical confidence in the metrics"),
  P(`With only ${cy.n} forecasts from 14 districts, every metric is uncertain. The evaluation therefore reports **95% confidence ranges from a cluster bootstrap**: districts (not individual rows) are resampled 2,000 times, because forecasts for one district are correlated (Efron and Tibshirani, 1993). A **paired bootstrap test** checks whether the model's advantage over the simple rule could be chance.`),
  table(["Metric", "Crop model: estimate (95% range)", "Dairy model: estimate (95% range)"], [
    ["RMSE", `${f2(cM.RMSE)} (${f2(ci.RMSE[0])} to ${f2(ci.RMSE[1])}) q/ha`, `${f2(dM.RMSE)} (${f2(dci.RMSE[0])} to ${f2(dci.RMSE[1])}) L/cow/day`],
    ["MAPE", `${f2(cM.MAPE, 1)}% (${f2(ci.MAPE[0], 1)} to ${f2(ci.MAPE[1], 1)})`, `${f2(dM.MAPE, 1)}% (${f2(dci.MAPE[0], 1)} to ${f2(dci.MAPE[1], 1)})`],
    ["R²", `${f2(cM.R2, 3)} (${f2(ci.R2[0], 3)} to ${f2(ci.R2[1], 3)})`, `${f2(dM.R2, 3)} (${f2(dci.R2[0], 3)} to ${f2(dci.R2[1], 3)})`],
    ["Skill vs last-period rule", `${pct(cM.Skill)} (${pct(ci.Skill[0])} to ${pct(ci.Skill[1])})`, `${pct(dM.Skill)} (${pct(dci.Skill[0])} to ${pct(dci.Skill[1])})`],
    ["RMSE difference vs rule", `${f2(cy.paired_rmse_diff.estimate)} (${f2(cy.paired_rmse_diff.lo)} to ${f2(cy.paired_rmse_diff.hi)}), p < 0.001`, `${f2(dm.paired_rmse_diff.estimate)} (${f2(dm.paired_rmse_diff.lo)} to ${f2(dm.paired_rmse_diff.hi)}), p < 0.001`],
  ], [2600, 3400, 3412], { boldFirst: true }),
  tcap("Cluster-bootstrap confidence ranges and paired test (negative RMSE difference means the model is better)."),
  P("Both confidence ranges for the model's advantage exclude zero, so the improvement over the simple rule is not a fluke of this particular test window. The width of the crop ranges (for example skill between 44% and 65%) is a reminder of how much a three-season test can and cannot say."),
  H2("4.5 Choosing metrics for each audience"),
  table(["Audience", "Lead with", "Support with", "Keep in the appendix"], [
    ["Executives", "Verdict, skill vs simple rule, planning-cost saving", "Report card", "All other metrics"],
    ["Planners", "MAPE, within-tolerance, bias %, range coverage", "Shortfall recall and precision", "RMSE, R², MASE"],
    ["Field officers", "Error by crop and district, hardest cases", "Early-warning list", "Calibration"],
    ["Data scientists", "RMSE, MAE, R², MASE, calibration, interval score", "Bootstrap ranges, drift", "-"],
  ], [1900, 3000, 2300, 2212], { boldFirst: true, size: 17 }),
  tcap("Metric selection by audience."),
  H2("4.6 Pre-agreed status thresholds"),
  P("To avoid judging results after the fact, green, amber and red limits are written into a configuration file (agrieval/config.py) and agreed with stakeholders in advance. The values below are proposed defaults and should be tuned per business case."),
  table(["Report-card question", "Metric", "GREEN", "AMBER", "RED"], [
    ["How big is a typical miss?", "MAPE", "≤ 10%", "≤ 15%", "> 15%"],
    ["Better than the simple rule?", "Skill score", "≥ 30%", "≥ 10%", "< 10%"],
    ["How often is it usable?", "Within ±10%", "≥ 65%", "≥ 50%", "< 50%"],
    ["Does it lean high or low?", "|Bias %|", "≤ 3%", "≤ 6%", "> 6%"],
    ["Can we trust the range?", "Coverage of 90% range", "≥ 88%", "≥ 80%", "< 80%"],
    ["Does it warn of bad seasons?", "Shortfall recall", "≥ 70%", "≥ 50%", "< 50%"],
  ], [3200, 2000, 1400, 1400, 1412], { boldFirst: true, align: [L, L, C, C, C] }),
  tcap("Traffic-light thresholds."),
  P("**Overall status rule.** RED if the error size or the skill score is red, or if two or more checks are red; AMBER if any check is red or amber; GREEN otherwise. A single red on a secondary check (for example bias) therefore produces AMBER with a mandatory action rather than a blanket rejection, while a model that is not better than the simple rule can never pass."),
];

// ---------- 5 ----------
const s5 = [
  H1p("5. Visualisation Plan for Non-Expert Stakeholders"),
  H2("5.1 Design principles"),
  B("**One message per chart,** stated in the title as a finding (\"Forecasts lean low\"), not a label (\"Bias by year\")."),
  B("**Real-world units and percentages,** such as quintal per hectare and percent error, rather than statistical jargon."),
  B("**Reference lines that show what good looks like:** the ±10% usable band, the promised 90% line, the target error."),
  B("**Always show the comparison:** model next to the simple rule."),
  B("**Colour plus text:** a colour-blind-safe palette (Okabe and Ito, 2008) with value labels and words such as GREEN or RED, so no information is carried by colour alone."),
  B("**Consistent meaning of colour:** blue is the model, grey is a baseline, green is good, orange/red is a problem, in every chart."),
  B("**Minimal clutter:** no 3-D, no dual axes, no decorative gridlines; direct value labels instead of legends where possible (Tufte, 2001; Few, 2012)."),
  B("**Honest scales:** bars start at zero; the same axis for comparable panels."),
  H2("5.2 Chart catalogue"),
  tcap("Planned visualisations, the question each answers and who it is for."),
  table(["#", "Chart", "Question answered", "Primary audience", "Design notes"], [
    ["1", "Report card", "Is the model good enough to use?", "Executives, planners", "Six questions in plain words; coloured status plus text"],
    ["2", "Model vs simple rules (bars with confidence range)", "How much better is the model?", "All", "Shorter bar is better; error bar shows uncertainty"],
    ["3", "Typical miss by segment", "Where is it strongest and weakest?", "Planners, field officers", "Sorted bars, target line, green/amber colouring"],
    ["4", "Actual vs forecast with 'usable' band", "Are forecasts close to reality?", "All", "Green ±10% band; points inside and outside coloured and counted"],
    ["5", "Error spread", "How far off can a forecast be?", "Planners", "Histogram with the usable zone shaded and its share stated"],
    ["6", "Over- and under-forecast by period", "Does it lean one way?", "Planners, executives", "Diverging bars, labelled percentages"],
    ["7", "Best and hardest cases", "What does a good and a bad forecast look like?", "Field officers, executives", "Small multiples: forecast, actual, 90% range"],
    ["8", "Shortfall early warning", "Does it warn us of bad seasons?", "Risk, insurance, relief", "Stacked counts: warned, missed, false alarm, vs simple rule"],
    ["9", "Planning cost", "Does it save money?", "Executives, finance", "Cost per unit with agreed weights; lower is better"],
    ["10", "Range reliability by segment", "Can we trust the range?", "Planners, risk", "Coverage by group against the promised 90% line"],
  ], [400, 2300, 2300, 1700, 2712], { size: 16, boldFirst: false }),
  H2("5.3 The charts in practice"),
  P("The following charts were produced automatically by the evaluation package for the crop-yield model. Each is followed by how a non-expert should read it."),
  ...evFig("crop_yield", "02_model_vs_simple_rules.png", 500, "Typical error size of the model compared with two simple rules, with the 95% confidence range for the model."),
  P(`**How to read it:** the shorter the bar the better. The model's typical error is ${f2(cM.RMSE)} quintal per hectare, against ${f2(T0[2][1])} and ${f2(T0[1][1])} for the simple rules. The black line shows that even in an unlucky sample the model would stay clearly ahead.`, { align: AlignmentType.LEFT }),
  ...evFig("crop_yield", "04_actual_vs_forecast.png", 400, "Every dot is one forecast. Dots in the green band are within ±10% of the real value."),
  P(`**How to read it:** the closer the dots are to the diagonal line, the better. ${pct(cM.WithinTol)} fall inside the green band. Orange dots below the line, mostly at high yields, are cases where the model forecast too little, which is the under-forecast bias discussed later.`, { align: AlignmentType.LEFT }),
  ...evFig("crop_yield", "03_typical_miss_by_segment.png", 440, "Average percentage miss by crop against the 10% target."),
  ...evFig("crop_yield", "05_error_spread.png", 460, "Distribution of forecast errors with the usable ±10% zone shaded."),
  ...evFig("crop_yield", "06_over_under_by_period.png", 440, "Average over- or under-forecast in each test year."),
  P("**How to read it:** all three bars point downwards, so the model forecast too little in every test year, and more so in 2023. A planner can act on this immediately by adding a margin to the forecast until the model is corrected.", { align: AlignmentType.LEFT }),
  ...evFig("crop_yield", "07_best_and_hardest_cases.png", 560, "Three best and three hardest district-crop combinations: forecast, actual and 90% range over the test years."),
  P("**How to read it:** the top row shows forecasts that track reality closely. The bottom row (all wheat) shows consistent under-forecasting, which tells field teams where better data are needed.", { align: AlignmentType.LEFT }),
  ...evFig("crop_yield", "08_shortfall_warning.png", 460, "Early warning of poor seasons by the model compared with the simple rule."),
  ...evFig("crop_yield", "09_planning_cost.png", 440, "Average planning cost per unit when a shortfall costs twice a surplus."),
  ...evFig("crop_yield", "10_range_reliability.png", 440, "Share of real outcomes inside the 90% range, by crop."),
  P("**How to read it:** the dashed line is what was promised. Ranges for cotton and tur are safe (even over-cautious), while rice and wheat fall well short, so those ranges should not be relied on until recalibrated.", { align: AlignmentType.LEFT }),
  H2("5.4 Common visualisation mistakes avoided"),
  table(["Mistake", "Why it misleads", "How the plan avoids it"], [
    ["Only showing R²", "Hides bias, segments and uncertainty", "Report card with six complementary questions"],
    ["Truncated or dual axes", "Exaggerates small differences", "Bars from zero, one axis per chart"],
    ["Colour-only encoding", "Unreadable for colour-blind readers and in black-and-white print", "Text labels and values on every status"],
    ["Averages without spread", "Conceals the bad cases that matter", "Error spread chart and hardest-cases panel"],
    ["Pooled results only", "Strong crops mask weak ones", "Segment charts for every report"],
    ["Showing the model alone", "No sense of added value", "Baselines in every comparison"],
  ], [2400, 3500, 3512], { boldFirst: true, size: 17 }),
  tcap("Pitfalls and countermeasures."),
];

// ---------- 6 ----------
const s6 = [
  H1p("6. Results of the Demonstration Evaluation"),
  callout("How to read this section", ["All figures are produced by python src/agrieval/run_evaluation.py from the hidden test forecasts of the Week 4 models (simulated data). Cost uses relative weights: shortfall = 2, surplus = 1."], "FFF2E0", ACCENT),
  spacer(100),
  H2("6.1 Crop-yield model against the simple rules"),
  tcap("Crop-yield test results (210 forecasts). RMSE and MAE in q/ha; Cost = relative planning cost per q/ha; Skill = error reduction vs last-season rule."),
  table(mh, mr(T0), mw, { align: mal, boldFirst: true, size: 15, hi: [0] }),
  spacer(80),
  P(`The model beats both simple rules on every measure. Its MASE of ${f2(T0[0][8])} means its average miss is about 42% of the miss from repeating last season. Planning cost falls by ${pct(cy.cost_saving)} compared with the last-season rule. The 3-season average is the stronger simple rule, which is why both are shown.`),
  H2("6.2 Where the model is strong and weak"),
  table(["Crop", "Typical miss (MAPE)", "RMSE (q/ha)", "Within ±10%", "Bias %", "90% range coverage"], cy.seg.map(r => [r[0], f2(r[1], 1) + "%", f2(r[2]), pct(r[3]), (r[4] >= 0 ? "+" : "") + f2(r[4], 1), pct(cy.coverage_by_segment[r[0]])]), [1800, 1700, 1500, 1500, 1200, 1712], { align: [L, R, R, R, R, R], boldFirst: true }),
  tcap("Crop-level results."),
  P("Four crops sit within the 10% target; wheat is the exception (11.1% typical miss, only 52% within tolerance, 8.4% under-forecast). Under-forecasting affects every crop, least for tur (-2.4%). The ranges for rice (64%) and wheat (74%) cover far fewer outcomes than promised, while cotton and tur are fully covered: the ranges have the same width for every crop, which is too narrow for high-variance crops and generous for low-variance ones."),
  table(["Year", "Typical miss (MAPE)", "Bias %"], cy.per.map(r => [String(r[0]), f2(r[1], 1) + "%", (r[2] >= 0 ? "+" : "") + f2(r[2], 1)]), [3000, 3200, 3212], { align: [L, R, R], boldFirst: true }),
  tcap("Results by test year."),
  P("Error is stable over time (about 8%), but the under-forecast grows to 7.9% in 2023, consistent with the input drift found in Week 4 (warming and expanding irrigation)."),
  H2("6.3 Early warning of poor seasons"),
  table(["", "Real shortfalls", "Warned in advance", "Missed", "False alarms", "Recall", "Precision"], [
    ["Model", String(DET.Events), String(DET.TP), String(DET.FN), String(DET.FP), pct(DET.Recall), pct(DET.Precision)],
    ["Simple rule (last season)", String(DETn.Events), String(DETn.TP), String(DETn.FN), String(DETn.FP), pct(DETn.Recall), pct(DETn.Precision)],
  ], [2500, 1300, 1400, 1000, 1200, 1000, 1012], { align: [L, R, R, R, R, R, R], boldFirst: true }),
  tcap("Shortfall detection (a shortfall is a yield below 85% of the 3-season average)."),
  P(`Of ${DET.Events} real shortfall cases the model warned of ${DET.TP} (${pct(DET.Recall)}), with ${pct(DET.Precision)} of its warnings correct, whereas the simple rule caught only ${DETn.TP}. This is the strongest evidence of business value and is the headline for risk, insurance and relief teams.`),
  H2("6.4 The same evaluation on a second model (dairy milk)"),
  tcap("Dairy test results (480 farm-months). RMSE and MAE in litres per cow per day."),
  table(mh, mr(DT0), mw, { align: mal, boldFirst: true, size: 15, hi: [0] }),
  spacer(80),
  P(`The dairy model is GREEN on all six report-card questions: ${f2(dM.MAPE, 1)}% typical miss, ${pct(dM.WithinTol)} of forecasts within ±10%, bias ${f2(dM.BiasPct, 1)}%, range coverage ${pct(dM.Coverage)}, and ${pct(dDET.Recall)} recall of shortfall months (precision ${pct(dDET.Precision)}; the simple rule catches ${pct(dDETn.Recall)}). Gir cattle are the least accurate breed (7.0% miss, small sample of 48 forecasts) and are flagged for monitoring. That the same code, thresholds and charts apply unchanged demonstrates that the evaluation strategy is not tied to one crop.`),
  ...evFig("dairy_milk", "01_scorecard.png", 500, "Report card for the dairy model, produced by the same code."),
];

// ---------- 7 ----------
const exCrop = [
  `**Verdict: AMBER.** The crop-yield model is usable for planning, provided the safeguards below are applied.`,
  `**What we tested:** 210 yield forecasts for 2021-2023 that the model had never seen, compared with 'same as last season'.`,
  `**Five numbers:** typical miss ${f2(cM.MAPE, 1)}%; ${pct(cM.Skill)} fewer errors than the simple rule; ${pct(cM.WithinTol)} of forecasts within ±10%; ${pct(DET.Recall)} of shortfall seasons warned in advance; planning cost ${pct(cy.cost_saving)} lower.`,
  `**What to watch:** the model forecasts ${f2(Math.abs(cM.BiasPct), 1)}% too low on average, and its 90% range is reliable for cotton and tur but not for rice and wheat.`,
  `**What we recommend:** (1) add a trend-adjusted target and retrain each season; (2) calibrate ranges by crop; (3) prioritise better wheat data; (4) re-test on real field data over five seasons.`,
  `**Decision requested:** approve use for procurement planning with a 5% upward margin on forecasts until the bias is corrected.`,
];
const s7 = [
  H1p("7. Reporting Strategy and Executive Summary"),
  H2("7.1 A layered reporting model"),
  P("Different readers need different depths. The strategy produces the same facts at three levels, so that a leader can stop after one page and an auditor can go all the way to the code."),
  ...fig("reporting_pyramid.png", 540, "Three reporting layers from executive one-pager to technical appendix."),
  H2("7.2 Structure of the executive summary"),
  tcap("Template for the one-page executive summary."),
  table(["Block", "Content", "Rule of thumb"], [
    ["1. Verdict", "Overall status (green, amber, red) and one-sentence meaning", "First line of the page; no jargon"],
    ["2. What was tested", "Number of forecasts, period, comparison used", "Two lines; states it is unseen data"],
    ["3. Five numbers", "Typical miss, improvement over the simple rule, usable share, early-warning rate, cost effect", "Each with a plain-language unit"],
    ["4. What to watch", "The one or two main weaknesses, with evidence", "Candid; never omit a red"],
    ["5. Recommendations", "Three to five prioritised actions", "Each action is specific and measurable"],
    ["6. Decision requested", "What the reader is asked to approve", "Ends the page"],
  ], [1900, 4300, 3212], { boldFirst: true }),
  H2("7.3 Example: executive summary for the crop-yield model"),
  P("The text below is the output of the evaluation package condensed to the template; the full auto-generated version is saved as executive_summary.md for every run."),
  callout("Executive summary: district-level crop-yield forecasting model", exCrop, LIGHT, PRIMARY),
  spacer(120),
  H2("7.4 Translating technical results into plain language"),
  table(["Technical statement", "Plain-language version"], [
    ["RMSE = 2.03 q/ha", "A typical forecast is about 2 quintal per hectare away from the real yield."],
    ["MAPE = 7.9%", "On average the forecast is 8% off."],
    ["R² = 0.94", "The forecasts capture about 94% of the ups and downs in yield between districts and seasons."],
    ["Bias = -6.4%", "The model tends to forecast about 6% too low, so plans based on it are on the cautious side."],
    ["Skill = 55%", "It makes about half the errors of the 'same as last year' rule."],
    ["Coverage = 86% at the 90% level", "The range we quote caught the real value 86 times in 100, slightly less than the 90 we promised."],
    ["Recall = 82%", "Of every 10 poor seasons, it warned us of about 8."],
    ["95% bootstrap interval 44-65%", "Even allowing for chance, the improvement is at least 44%."],
  ], [3600, 5812], { boldFirst: true, size: 17 }),
  tcap("Translation guide used in all stakeholder material."),
  H2("7.5 Cadence, channels and ownership"),
  table(["Report", "Audience", "Frequency", "Format", "Owner"], [
    ["Executive one-pager", "Leadership", "Each forecast cycle and each retrain", "PDF or one slide", "Lead data scientist"],
    ["Stakeholder briefing", "Planners, field officers, risk", "Each season, after actuals arrive", "6-8 page report and short meeting", "Data scientist"],
    ["Technical appendix", "Data science, audit", "Each model version", "Notebook, CSV, code release", "Data scientist"],
    ["Monitoring alert", "Model owner", "Weekly in season", "Short message with metric and threshold", "Automated"],
  ], [1900, 1900, 2100, 2000, 1512], { boldFirst: true, size: 16 }),
  tcap("Reporting cadence."),
  H2("7.6 Presenting results: guidelines"),
  N("Lead with the verdict and the decision it supports; show methods last.", "n1"),
  N("Use at most five numbers on a slide and one chart per message.", "n1"),
  N("State uncertainty in words ('about 8 out of 10') as well as numbers.", "n1"),
  N("Show a good and a bad example (hardest cases) so the audience builds a realistic feel for the model.", "n1"),
  N("Pair every weakness with a proposed fix and the metric that will show it worked.", "n1"),
  N("Close with a specific request, not a general summary.", "n1"),
];

// ---------- 8 ----------
const s8 = [
  H1p("8. Recommendations for Improving the Model"),
  P("Recommendations are derived directly from the evaluation evidence and ranked by expected benefit and effort. Each has a metric that will confirm whether it worked."),
  table(["#", "Recommendation", "Evidence", "Expected effect", "Effort", "How to verify"], [
    ["1", "Remove the systematic under-forecast: model the ratio to a recent local mean or add a trend term; retrain every season", `Bias ${f2(cM.BiasPct, 1)}% (RED), worsening to -7.9% in 2023; drift in temperature and irrigation`, "Bias within ±3%; planning cost falls further", "Low-medium", "Bias % and planning cost on the next test season"],
    ["2", "Calibrate prediction ranges per crop (or proportional to the forecast)", "Coverage 86% overall; rice 64%, wheat 74%, cotton and tur 100%", "Coverage near 90% for every crop", "Low", "Coverage by crop chart"],
    ["3", "Target wheat with better inputs (rabi weather, irrigation timing) or a wheat-specific model", "Wheat miss 11.1% vs 6.5-7.5% for other crops; 52% within tolerance", "Wheat MAPE below 10%", "Medium", "Typical-miss chart by crop"],
    ["4", "Prioritise management and satellite data collection; drop redundant identity columns", "Week 4 ablation: removing management or NDVI hurts most; removing district codes slightly improved error", "Simpler, more robust model", "Low", "Ablation and drift reports"],
    ["5", "Tune the shortfall alert threshold on cost, and add in-season indicators", `Recall ${pct(DET.Recall)} but ${DET.FP} false alarms`, "Higher recall at similar precision", "Medium", "Recall, precision and cost"],
    ["6", "Re-evaluate on real district data over at least five seasons", "Three simulated test seasons only", "Credible, decision-grade metrics", "High", "Full report regenerated"],
  ], [380, 2600, 2400, 1600, 800, 1632], { size: 15 }),
  tcap("Prioritised improvement plan."),
  P("Recommendations 1 and 2 are quick wins that address the two red/amber items on the report card. Recommendation 6 is the gating item before any budget decision, because every other conclusion rests on it."),
];

// ---------- 9 ----------
const s9 = [
  H1p("9. Limitations and Further Refinement"),
  H2("9.1 Limitations of the evaluation"),
  table(["Limitation", "Why it matters", "Mitigation"], [
    ["Simulated data", "Accuracy numbers reflect the simulator, not field reality", "Methodology and code are unchanged for real data; re-run before decisions"],
    ["Short test window (3 seasons, 14 districts)", "Wide confidence ranges; rare events (droughts) barely represented", "Cluster bootstrap; extend to rolling-origin evaluation over more seasons"],
    ["Pooled metrics across crops", "R² and rank agreement are inflated by large differences between crops", "Report MAPE and segment results; never rely on pooled R²"],
    ["Assumed cost weights and tolerance", "Business value depends on the 2:1 weight and ±10% band", "Confirm with finance and operations; run sensitivity analysis"],
    ["Single naive benchmark family", "A stronger benchmark (for example official forecasts or expert estimates) may narrow the gain", "Add current practice as a baseline when available"],
    ["Association not causation", "Importance and ablation show what the model uses, not what a change would cause", "Use experiments or causal methods before recommending interventions"],
    ["Static threshold definitions", "An 85% shortfall rule or a 10% tolerance may not suit every crop", "Review thresholds with agronomists; make them crop-specific"],
  ], [2400, 3500, 3512], { boldFirst: true, size: 17 }),
  tcap("Limitations of the evaluation approach and how they are handled."),
  H2("9.2 Limitations of the model revealed by the evaluation"),
  B("**Under-forecasting under drift:** tree-based models cannot extrapolate beyond the training range, so upward trends are under-predicted."),
  B("**Uneven range reliability:** one global interval width treats all crops alike."),
  B("**Weak wheat performance:** rabi-season dynamics are less well captured by the inputs."),
  B("**False alarms in shortfall warnings** remain at roughly one in four warnings."),
  H2("9.3 Roadmap for further refinement"),
  table(["Refinement", "What it involves", "Metric that should improve"], [
    ["Trend-adjusted or ratio target", "Predict the ratio to the entity's recent mean, or add a linear trend component", "Bias %, MAPE in latest year"],
    ["Mondrian (group-wise) conformal ranges", "Calibrate range width separately for each crop or region", "Coverage by segment"],
    ["Quantile or probabilistic models", "Forecast the full distribution, not only a point and a range", "Interval score, calibration slope"],
    ["Hierarchical (partial pooling) models", "Share strength across districts, helping sparse ones", "Leave-district-out error"],
    ["Rolling-origin back-testing", "Re-evaluate over many forecast origins instead of one split", "Narrower confidence ranges"],
    ["Value-based evaluation", "Link forecast errors to rupee impact with finance", "Planning cost in rupees"],
    ["Human comparison", "Compare with extension-officer or official estimates", "Skill vs current practice"],
    ["Fairness checks across regions", "Review error and coverage for small or poorer districts", "Segment gap in MAPE and coverage"],
  ], [2700, 4000, 2712], { boldFirst: true, size: 17 }),
  tcap("Refinement roadmap."),
];

// ---------- 10 ----------
const s10 = [
  H1n("10. Monitoring and Governance"),
  P("Evaluation does not end at launch. Once actual outcomes become available each season, the same pipeline is re-run, and pre-agreed triggers decide whether the model continues, is recalibrated or is retrained."),
  table(["Signal", "Trigger", "Action"], [
    ["Typical miss (MAPE)", "Above 15% (red) or rising 3 periods in a row", "Investigate drift; retrain"],
    ["Bias %", "Outside ±6% (red)", "Apply correction margin; retrain with newest data"],
    ["Range coverage", "Below 80% overall or any crop below 70%", "Recalibrate ranges"],
    ["Skill vs simple rule", "Below 10%", "Stop using for decisions; review"],
    ["Input drift (PSI)", "Above 0.25 on a key input", "Review inputs; consider retraining"],
    ["Shortfall recall", "Below 50%", "Re-tune threshold and add indicators"],
  ], [2600, 3600, 3212], { boldFirst: true }),
  tcap("Monitoring triggers."),
  H2("10.1 Governance practices"),
  B("**Model card:** a one-page record of purpose, data, test results, limits and owner for each version (Mitchell et al., 2019)."),
  B("**Version control and reproducibility:** fixed seeds, saved predictions, metric tables and charts for every evaluation run."),
  B("**Sign-off:** a data scientist and a business owner review the report card before a model is promoted."),
  B("**Transparency to users:** the weaknesses on the report card are shared with those who rely on the forecasts."),
  B("**Data protection:** farm-level data are aggregated or anonymised in all reports."),
];

// ---------- 11 ----------
const s11 = [
  H1p("11. Conclusion"),
  P("Good evaluation turns a model into a decision tool. This report set out a methodical strategy that (1) defines success with the end user in mind, (2) measures performance with a balanced set of error, decision, uncertainty and confidence metrics, (3) presents results through simple, honest and accessible visuals, (4) communicates through a layered reporting model that leads with a verdict and ends with a specific request, and (5) closes the loop with recommendations, limitations and monitoring."),
  P(`The strategy was applied to working models. The crop-yield model earned an AMBER status: strongly better than simple rules (${pct(cM.Skill)} fewer errors, ${pct(DET.Recall)} of shortfall seasons anticipated, ${pct(cy.cost_saving)} lower planning cost) but biased low by ${f2(Math.abs(cM.BiasPct), 1)}% with unevenly reliable prediction ranges. The dairy model earned GREEN on the same checks with unchanged code. The evaluation is therefore both specific enough to drive improvement and general enough to apply to other agribusiness problems.`),
  P("The most important next step is to apply the same procedure to real regional data, over several seasons, with cost weights agreed with the business. Because the evaluation is automated, that step requires only new input files, and the resulting report card will show stakeholders, in plain language, how far each forecast can be trusted."),
];

const refs = [
  "Efron, B. and Tibshirani, R. J. (1993). An Introduction to the Bootstrap. Chapman and Hall.",
  "Few, S. (2012). Show Me the Numbers: Designing Tables and Graphs to Enlighten (2nd ed.). Analytics Press.",
  "Gneiting, T. and Raftery, A. E. (2007). Strictly proper scoring rules, prediction, and estimation. Journal of the American Statistical Association, 102(477), 359-378.",
  "Hyndman, R. J. and Koehler, A. B. (2006). Another look at measures of forecast accuracy. International Journal of Forecasting, 22(4), 679-688.",
  "Chai, T. and Draxler, R. R. (2014). Root mean square error (RMSE) or mean absolute error (MAE)? Arguments against avoiding RMSE in the literature. Geoscientific Model Development, 7, 1247-1250.",
  "Willmott, C. J. and Matsuura, K. (2005). Advantages of the mean absolute error (MAE) over the root mean square error (RMSE) in assessing average model performance. Climate Research, 30, 79-82.",
  "Mitchell, M. et al. (2019). Model cards for model reporting. Proceedings of the Conference on Fairness, Accountability, and Transparency, 220-229.",
  "Okabe, M. and Ito, K. (2008). Color Universal Design (CUD): how to make figures and presentations that are friendly to colorblind people.",
  "Tufte, E. R. (2001). The Visual Display of Quantitative Information (2nd ed.). Graphics Press.",
  "Vovk, V., Gammerman, A. and Shafer, G. (2005). Algorithmic Learning in a Random World. Springer.",
  "Bergmeir, C. and Benitez, J. M. (2012). On the use of cross-validation for time series predictor evaluation. Information Sciences, 191, 192-213.",
  "van Klompenburg, T., Kassahun, A. and Catal, C. (2020). Crop yield prediction using machine learning: A systematic literature review. Computers and Electronics in Agriculture, 177, 105709.",
];
const sRefs = [H1p("References"), ...refs.map(r => new Paragraph({ spacing: { after: 100, line: 276 }, indent: { left: 480, hanging: 480 }, children: rich(r, { size: 20 }) }))];

const sApp = [
  H1p("Appendix A. Plain-Language Glossary"),
  table(["Term", "Meaning"], [
    ["Hidden test set", "Data the model never saw while it was built; used once to judge it fairly."],
    ["Baseline / simple rule", "An easy alternative, such as 'same as last season', used to show whether the model adds value."],
    ["Skill score", "How much smaller the model's errors are than the simple rule's (55% = about half the errors)."],
    ["Bias", "A tendency to forecast too high or too low."],
    ["Prediction range (90%)", "A band that should contain the real value about 9 times in 10."],
    ["Coverage", "How often the real value actually fell inside the band."],
    ["Confidence range (bootstrap)", "The range within which a reported metric would likely fall if the test were repeated with different data."],
    ["Recall", "Of all real bad seasons, the share the model warned about."],
    ["Precision", "Of all warnings issued, the share that were correct."],
    ["Drift", "A gradual change in conditions (such as warming) that makes older patterns less reliable."],
    ["Cluster", "A group of related records, such as all forecasts for one district."],
  ], [2800, 6612], { boldFirst: true }),
  tcap("Glossary used in stakeholder reports."),
  H1p("Appendix B. Implementation and Reproduction"),
  table(["Path", "Content"], [
    ["src/agrieval/metrics.py", "All metrics, cluster bootstrap and paired test"],
    ["src/agrieval/scorecard.py", "Traffic-light logic and auto-generated executive summary"],
    ["src/agrieval/visuals.py", "Ten stakeholder charts"],
    ["src/agrieval/config.py", "Tolerance, cost weights and thresholds (evaluation policy)"],
    ["src/agrieval/run_evaluation.py", "Orchestrator and command-line entry"],
    ["tests/test_evaluation.py", "Ten unit tests for metrics and scorecard rules"],
    ["outputs/evaluation/<scenario>/", "executive_summary.md, evaluation_summary.json, metric CSVs, figures"],
  ], [3500, 5912], { boldFirst: true, size: 18 }),
  tcap("Evaluation package layout."),
  ...["python run_pipeline.py --scenario all --n-iter 12", "python src/agrieval/run_evaluation.py", "python -m unittest discover -s tests"].map((c, i) =>
    new Paragraph({ shading: { fill: "F2F4F6", type: ShadingType.CLEAR, color: "auto" }, spacing: { after: i === 2 ? 160 : 40 }, children: [run(c, { font: "Consolas", size: 19 })] })),
  P("To evaluate any other model, supply a CSV of forecasts with the entity and time columns plus y_pred, lo and hi; the package recomputes baselines, metrics, charts and the executive summary."),
];

// ---------- assemble ----------
const headStyle = (size, color, before, after) => ({ run: { size, bold: true, color, font: "Calibri" }, paragraph: { spacing: { before, after }, keepNext: true } });
const doc = new Document({
  creator: "Sumit Kumar Sharma", title: "Model Evaluation and Reporting Strategy", description: "Week 5 task report",
  styles: {
    default: { document: { run: { font: "Calibri", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, ...headStyle(36, PRIMARY, 120, 200), paragraph: { spacing: { before: 120, after: 200 }, keepNext: true, outlineLevel: 0, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: ACCENT, space: 4 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, ...headStyle(27, PRIMARY, 260, 120), paragraph: { spacing: { before: 260, after: 120 }, keepNext: true, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, ...headStyle(23, "33414A", 200, 100), paragraph: { spacing: { before: 200, after: 100 }, keepNext: true, outlineLevel: 2 } },
    ],
  },
  numbering: { config: [
    { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 640, hanging: 300 } } } }] },
    ...numRefs.map(r => ({ reference: r, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 640, hanging: 360 } } } }] })),
  ] },
  sections: [
    { properties: { page: { size: { width: PAGE_W, height: PAGE_H }, margin: { top: 1247, bottom: 1247, left: MARGIN, right: MARGIN } } }, children: cover },
    { properties: { page: { size: { width: PAGE_W, height: PAGE_H }, margin: { top: 1400, bottom: 1247, left: MARGIN, right: MARGIN }, pageNumbers: { start: 2 } } },
      headers: { default: new Header({ children: [new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: BORDER, space: 4 } }, tabStops: [{ type: TabStopType.RIGHT, position: CW }],
        children: [run("Model Evaluation and Reporting Strategy", { size: 17, color: GREY }), run("\tSumit Kumar Sharma", { size: 17, color: GREY })] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [run("Page ", { size: 17, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], size: 17, color: GREY })] })] }) },
      children: [...tocBlock, ...s1, ...s2, ...s3, ...s4, ...s5, ...s6, ...s7, ...s8, ...s9, ...s10, ...s11, ...sRefs, ...sApp] },
  ],
});
const outFile = path.join(__dirname, "..", "Sumit_Kumar_Sharma_Model_Evaluation_Reporting_Strategy.docx");
Packer.toBuffer(doc).then(b => { fs.writeFileSync(outFile, b); console.log("written", outFile, (b.length / 1024).toFixed(0) + " KB"); });
