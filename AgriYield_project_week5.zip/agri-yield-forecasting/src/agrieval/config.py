"""Evaluation policy: thresholds for the traffic-light scorecard and business-cost assumptions.

All values are *assumptions to be agreed with stakeholders* and are deliberately kept in one place.
"""
from dataclasses import dataclass, field


@dataclass
class Thresholds:
    # (green_if_at_most / at_least, amber_boundary); direction given by name
    mape_green: float = 10.0          # % error: <= green, <= amber, else red
    mape_amber: float = 15.0
    skill_green: float = 0.30         # improvement over naive: >= green, >= amber, else red
    skill_amber: float = 0.10
    coverage_green: float = 0.88      # 90% interval should cover >= 88%
    coverage_amber: float = 0.80
    bias_green: float = 3.0           # |bias| as % of mean actual
    bias_amber: float = 6.0
    within_tol_green: float = 0.65    # share of forecasts within +/- tolerance
    within_tol_amber: float = 0.50
    recall_green: float = 0.70        # shortfall-detection recall
    recall_amber: float = 0.50


@dataclass
class EvalPolicy:
    tolerance_pct: float = 10.0       # a forecast is "usable" if within +/-10% of actual
    shortfall_ratio: float = 0.85     # a shortfall = actual below 85% of the trailing 3-period mean
    under_cost: float = 2.0           # relative cost of under-forecasting 1 unit (stock-out / spot purchase)
    over_cost: float = 1.0            # relative cost of over-forecasting 1 unit (storage / idle capacity)
    n_boot: int = 2000
    seed: int = 42
    thresholds: Thresholds = field(default_factory=Thresholds)
