"""AgriEval: model evaluation and stakeholder reporting for agribusiness forecasts."""
__version__ = "1.0.0"
