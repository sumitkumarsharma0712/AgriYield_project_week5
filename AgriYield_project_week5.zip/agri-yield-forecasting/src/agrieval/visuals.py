"""Stakeholder-oriented charts: one message per chart, plain-language titles, colour + text (never colour alone)."""
from __future__ import annotations
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker
import numpy as np
import pandas as pd

BLUE, ORANGE, GREEN, RED, GREY, SKY, PURPLE = "#0072B2", "#E69F00", "#009E73", "#D55E00", "#6B7280", "#56B4E9", "#CC79A7"
STATUS = {"GREEN": GREEN, "AMBER": ORANGE, "RED": RED}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "axes.titlesize": 12.5, "axes.titlelocation": "left", "figure.dpi": 130,
                     "savefig.bbox": "tight", "axes.grid": True, "grid.alpha": .22, "axes.axisbelow": True})


def _save(fig, path):
    fig.savefig(path, dpi=200); plt.close(fig)


def scorecard(rows, overall, title, path):
    fig, ax = plt.subplots(figsize=(10, .62 * len(rows) + 1.5)); ax.axis("off")
    ax.set_xlim(0, 10); ax.set_ylim(0, len(rows) + 1.1)
    ax.text(0, len(rows) + .75, title, fontsize=14, fontweight="bold", va="center")
    ax.text(10, len(rows) + .75, f"Overall: {overall}", fontsize=13, fontweight="bold", color=STATUS[overall], ha="right", va="center")
    for i, (q, v, s, _) in enumerate(rows):
        y = len(rows) - i - .25
        ax.add_patch(plt.Rectangle((0, y - .38), 10, .76, color="#F5F8FA" if i % 2 == 0 else "white", zorder=0))
        ax.text(.15, y, q, va="center", fontsize=11)
        ax.text(5.3, y, v, va="center", fontsize=10.5, fontweight="bold")
        ax.add_patch(plt.Rectangle((8.45, y - .25), 1.4, .5, color=STATUS[s], zorder=2))
        ax.text(9.15, y, s, color="white", ha="center", va="center", fontsize=10, fontweight="bold", zorder=3)
    _save(fig, path)


def model_vs_baselines(res: pd.DataFrame, unit, path):
    """res index: label; columns RMSE, lo, hi (CI for the model only may be NaN)."""
    res = res.sort_values("RMSE", ascending=False)
    cols = [BLUE if "Model" in i else GREY for i in res.index]
    fig, ax = plt.subplots(figsize=(8, 3.2))
    ax.barh(res.index, res["RMSE"], color=cols, height=.6)
    for i, (idx, r) in enumerate(res.iterrows()):
        if "Model" in idx and not np.isnan(r["lo"]):
            ax.errorbar(r["RMSE"], i, xerr=[[r["RMSE"] - r["lo"]], [r["hi"] - r["RMSE"]]], color="k", capsize=4, lw=1.4)
        ax.text(r["RMSE"] + (r["hi"] - r["RMSE"] if "Model" in idx and not np.isnan(r["hi"]) else 0) + .03 * res["RMSE"].max(), i, f"{r['RMSE']:.2f}", va="center", fontsize=10)
    ax.set(xlabel=f"typical error size, RMSE ({unit}) - shorter bar is better", title="The model's errors are much smaller than the simple rules'")
    ax.set_xlim(0, res["RMSE"].max() * 1.2); ax.grid(axis="y", alpha=0)
    _save(fig, path)


def typical_miss(seg: pd.DataFrame, seg_name, tol, path):
    d = seg.sort_values("MAPE")
    fig, ax = plt.subplots(figsize=(7.5, max(2.8, .42 * len(d) + 1.2)))
    cols = [GREEN if v <= tol else ORANGE if v <= 1.5 * tol else RED for v in d["MAPE"]]
    ax.barh(d.index.astype(str), d["MAPE"], color=cols, height=.62)
    ax.axvline(tol, color="k", ls="--", lw=1); ax.text(tol + .15, -.45, f"target: {tol:.0f}%", fontsize=9, va="center")
    for i, v in enumerate(d["MAPE"]): ax.text(v + .15, i, f"{v:.1f}%", va="center", fontsize=10)
    ax.set(xlabel="average miss, % of actual value", title=f"Where the forecasts are closest and furthest, by {seg_name}")
    ax.set_xlim(0, d["MAPE"].max() * 1.2); ax.grid(axis="y", alpha=0)
    _save(fig, path)


def actual_vs_forecast(df, unit, tol, path):
    fig, ax = plt.subplots(figsize=(6, 5.6))
    lim = [min(df.y_true.min(), df.y_pred.min()) * .95, max(df.y_true.max(), df.y_pred.max()) * 1.04]
    x = np.linspace(*lim, 50)
    ax.fill_between(x, x * (1 - tol / 100), x * (1 + tol / 100), color=GREEN, alpha=.16, label=f"within +/-{tol:.0f}% (usable)")
    ax.plot(x, x, color=GREEN, lw=1.4, label="perfect forecast")
    inside = (df.y_pred >= df.y_true * (1 - tol / 100)) & (df.y_pred <= df.y_true * (1 + tol / 100))
    ax.scatter(df.y_true[inside], df.y_pred[inside], s=14, color=BLUE, alpha=.65, edgecolor="none", label=f"usable ({inside.mean():.0%})")
    ax.scatter(df.y_true[~inside], df.y_pred[~inside], s=18, color=RED, alpha=.8, edgecolor="none", label=f"off target ({(~inside).mean():.0%})")
    ax.set(xlim=lim, ylim=lim, xlabel=f"what actually happened ({unit})", ylabel=f"what the model forecast ({unit})",
           title="Most forecasts sit inside the green 'usable' band"); ax.legend(frameon=False, fontsize=9, loc="upper left")
    _save(fig, path)


def over_under_by_period(df, time_col, path):
    g = df.assign(e=(df.y_pred - df.y_true) / df.y_true * 100).groupby(time_col)["e"].mean()
    fig, ax = plt.subplots(figsize=(7.5, 3.3))
    x = np.arange(len(g))
    ax.bar(x, g.values, color=[RED if v < 0 else BLUE for v in g.values], width=.55)
    ax.axhline(0, color="k", lw=.8)
    for i, v in enumerate(g.values):
        ax.text(i, v + (.25 if v >= 0 else -.25), f"{v:+.1f}%", ha="center", va="bottom" if v >= 0 else "top", fontsize=10)
    step = max(1, len(g) // 8)
    ax.set_xticks(x[::step]); ax.set_xticklabels([str(int(i)) for i in g.index[::step]])
    lean = "low" if g.mean() < 0 else "high"
    ax.set(ylabel="forecast minus actual, %", xlabel=time_col, title=f"Forecasts lean {lean} on average (red = under-forecast, blue = over-forecast)")
    ax.grid(axis="x", alpha=0); ax.margins(y=.3)
    _save(fig, path)


def error_spread(df, tol, path):
    pe = (df.y_pred - df.y_true) / df.y_true * 100
    fig, ax = plt.subplots(figsize=(7.5, 3.4))
    lo, hi = max(-40, pe.min()), min(40, pe.max())
    ax.axvspan(-tol, tol, color=GREEN, alpha=.16); ax.hist(pe.clip(lo, hi), bins=40, color=BLUE, alpha=.85)
    ax.axvline(0, color="k", lw=.8)
    ax.text(0, ax.get_ylim()[1] * .93, f"{((pe.abs() <= tol).mean()):.0%} of forecasts\nwithin +/-{tol:.0f}%", ha="center", va="top", fontsize=10, fontweight="bold", color="#065F46")
    ax.set(xlabel="forecast error, % of actual (negative = forecast too low)", ylabel="number of forecasts", title="How far off are the forecasts?")
    _save(fig, path)


def small_multiples(df, entity_label, time_col, unit, picks, path):
    n = len(picks); cols = 3; rows = int(np.ceil(n / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(11, 2.9 * rows), sharex=False); axes = np.atleast_1d(axes).ravel()
    for ax, (name, tag) in zip(axes, picks):
        g = df[df[entity_label] == name].sort_values(time_col)
        ax.fill_between(g[time_col], g.lo, g.hi, color=SKY, alpha=.35, label="90% range")
        ax.plot(g[time_col], g.y_pred, color=BLUE, marker="o", lw=2, label="forecast")
        ax.plot(g[time_col], g.y_true, color=RED, marker="s", lw=2, label="actual")
        ax.set_title(f"{name}  ({tag})", fontsize=10.5); ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True, nbins=4))
    for ax in axes[n:]: ax.axis("off")
    axes[0].legend(frameon=False, fontsize=8); fig.supylabel(unit, fontsize=10); fig.tight_layout(); _save(fig, path)


def shortfall_chart(det: dict, path):
    """det: {label: {TP, FN, FP}}"""
    fig, ax = plt.subplots(figsize=(7.5, 3.0)); labels = list(det)
    tp = [det[k]["TP"] for k in labels]; fn = [det[k]["FN"] for k in labels]; fp = [det[k]["FP"] for k in labels]
    ax.barh(labels, tp, color=GREEN, label="shortfall correctly warned", height=.55)
    ax.barh(labels, fn, left=tp, color=RED, label="shortfall missed", height=.55)
    ax.barh(labels, fp, left=np.array(tp) + np.array(fn), color=ORANGE, label="false alarm", height=.55)
    for i, k in enumerate(labels):
        tot = det[k]["TP"] + det[k]["FN"]
        ax.text(tp[i] / 2, i, f"{tp[i]}", color="white", ha="center", va="center", fontweight="bold")
        if fn[i]: ax.text(tp[i] + fn[i] / 2, i, f"{fn[i]}", color="white", ha="center", va="center", fontweight="bold")
        if fp[i]: ax.text(tp[i] + fn[i] + fp[i] / 2, i, f"{fp[i]}", color="black", ha="center", va="center", fontweight="bold")
    ax.set(xlabel="number of cases", title="Early warning of poor seasons: model vs simple rule"); ax.legend(frameon=False, fontsize=9, loc="upper center", bbox_to_anchor=(.5, -.28), ncol=3); ax.grid(axis="y", alpha=0)
    _save(fig, path)


def cost_chart(costs: dict, path):
    s = pd.Series(costs).sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(7.5, 2.9))
    ax.barh(s.index, s.values, color=[BLUE if "Model" in i else GREY for i in s.index], height=.6)
    for i, v in enumerate(s.values): ax.text(v + .01 * s.max(), i, f"{v:.2f}", va="center", fontsize=10)
    ax.set(xlabel="average planning cost per unit forecast (cost units, lower is better)", title="Planning cost when shortfalls hurt more than surpluses")
    ax.set_xlim(0, s.max() * 1.15); ax.grid(axis="y", alpha=0)
    _save(fig, path)


def range_reliability(cov_by: pd.Series, nominal, path):
    d = cov_by.sort_values()
    fig, ax = plt.subplots(figsize=(7.5, max(2.8, .4 * len(d) + 1.2)))
    ax.barh(d.index.astype(str), d.values * 100, color=[GREEN if v >= nominal - .04 else ORANGE if v >= nominal - .12 else RED for v in d.values], height=.6)
    ax.axvline(nominal * 100, color="k", ls="--", lw=1); ax.text(nominal * 100, len(d) - .4, " promised 90%", fontsize=9, va="bottom")
    for i, v in enumerate(d.values): ax.text(v * 100 + 1, i, f"{v:.0%}", va="center", fontsize=10)
    ax.set(xlabel="% of real outcomes that fell inside the forecast range", title="Can the forecast range be trusted?", xlim=(0, 108)); ax.grid(axis="y", alpha=0)
    _save(fig, path)
