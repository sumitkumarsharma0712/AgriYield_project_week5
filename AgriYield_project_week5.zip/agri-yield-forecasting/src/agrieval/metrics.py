"""Evaluation metrics beyond RMSE/MAE: scale-free, business-cost, interval, detection and uncertainty of the metric itself."""
from __future__ import annotations
from typing import Callable, Dict
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


# ---------------- point-forecast accuracy ----------------
def point_metrics(y, p, tolerance_pct: float = 10.0) -> Dict[str, float]:
    y, p = np.asarray(y, float), np.asarray(p, float)
    err = p - y
    ape = np.abs(err) / np.clip(np.abs(y), 1e-9, None)
    return dict(
        RMSE=float(np.sqrt(mean_squared_error(y, p))),
        MAE=float(mean_absolute_error(y, p)),
        MAPE=float(ape.mean() * 100),
        WAPE=float(np.abs(err).sum() / np.abs(y).sum() * 100),
        R2=float(r2_score(y, p)),
        Bias=float(err.mean()),
        BiasPct=float(err.mean() / y.mean() * 100),
        WithinTol=float((ape * 100 <= tolerance_pct).mean()),
        P90_AbsErrPct=float(np.quantile(ape, 0.9) * 100),
    )


def skill(rmse_model: float, rmse_ref: float) -> float:
    return 1 - rmse_model / rmse_ref


def mase(y, p, y_naive) -> float:
    """Mean absolute scaled error: MAE of the model divided by MAE of a naive forecast on the same rows (<1 beats naive)."""
    return float(np.mean(np.abs(np.asarray(y) - np.asarray(p))) / np.mean(np.abs(np.asarray(y) - np.asarray(y_naive))))


def calibration_fit(y, p) -> Dict[str, float]:
    """Regress actual on forecast. Ideal: slope 1, intercept 0 (forecasts neither too timid nor too extreme)."""
    slope, intercept = np.polyfit(np.asarray(p, float), np.asarray(y, float), 1)
    return dict(CalSlope=float(slope), CalIntercept=float(intercept))


def asymmetric_cost(y, p, under_cost: float = 2.0, over_cost: float = 1.0) -> float:
    """Average business cost per unit when under- and over-forecasting are not equally costly."""
    e = np.asarray(p, float) - np.asarray(y, float)
    return float(np.mean(np.where(e < 0, -e * under_cost, e * over_cost)))


def rank_agreement(df: pd.DataFrame, by: str, y="y_true", p="y_pred") -> float:
    """Spearman correlation between forecast and actual *across entities* within each period, averaged.
    Answers: does the model rank districts/farms correctly (useful for prioritising support)?"""
    out = []
    for _, g in df.groupby(by):
        if g[y].nunique() > 2 and len(g) > 4:
            out.append(g[y].rank().corr(g[p].rank()))
    return float(np.nanmean(out)) if out else float("nan")


# ---------------- event detection (shortfall early warning) ----------------
def detection_metrics(actual_event: np.ndarray, pred_event: np.ndarray) -> Dict[str, float]:
    a, b = np.asarray(actual_event, bool), np.asarray(pred_event, bool)
    tp, fp, fn, tn = int((a & b).sum()), int((~a & b).sum()), int((a & ~b).sum()), int((~a & ~b).sum())
    prec = tp / (tp + fp) if tp + fp else float("nan")
    rec = tp / (tp + fn) if tp + fn else float("nan")
    f1 = 2 * prec * rec / (prec + rec) if (prec == prec and rec == rec and prec + rec > 0) else float("nan")
    return dict(TP=tp, FP=fp, FN=fn, TN=tn, Precision=prec, Recall=rec, F1=f1, Events=int(a.sum()))


# ---------------- interval quality ----------------
def interval_metrics(y, lo, hi, alpha: float = 0.10) -> Dict[str, float]:
    y, lo, hi = map(lambda x: np.asarray(x, float), (y, lo, hi))
    cover = float(np.mean((y >= lo) & (y <= hi)))
    width = float(np.mean(hi - lo))
    # Winkler / interval score (lower is better): width + penalty for misses
    pen = (2 / alpha) * (np.clip(lo - y, 0, None) + np.clip(y - hi, 0, None))
    return dict(Coverage=cover, MeanWidth=width, IntervalScore=float(np.mean(hi - lo + pen)))


# ---------------- uncertainty OF the metric ----------------
def cluster_bootstrap(df: pd.DataFrame, fn: Callable[[pd.DataFrame], float], cluster: str,
                      n_boot: int = 2000, seed: int = 42, level: float = 0.95):
    """Resample whole clusters (districts / farms) so that correlated rows are not treated as independent."""
    rng = np.random.default_rng(seed)
    groups = {k: g for k, g in df.groupby(cluster)}
    keys = list(groups)
    vals = []
    for _ in range(n_boot):
        pick = rng.choice(len(keys), len(keys), replace=True)
        vals.append(fn(pd.concat([groups[keys[i]] for i in pick], ignore_index=True)))
    vals = np.array(vals)
    a = (1 - level) / 2
    return float(np.quantile(vals, a)), float(np.quantile(vals, 1 - a)), vals


def paired_bootstrap_diff(df: pd.DataFrame, pred_a: str, pred_b: str, cluster: str, n_boot=2000, seed=42):
    """RMSE(a) - RMSE(b) with 95% CI and a two-sided p-value for H0: no difference. Negative => a is better."""
    f = lambda d: np.sqrt(np.mean((d[pred_a] - d["y_true"]) ** 2)) - np.sqrt(np.mean((d[pred_b] - d["y_true"]) ** 2))
    lo, hi, v = cluster_bootstrap(df, f, cluster, n_boot, seed)
    est = float(f(df))
    p = float(2 * min((v >= 0).mean(), (v <= 0).mean()))
    return est, lo, hi, max(p, 1 / n_boot)


def segment_metrics(df: pd.DataFrame, by: str, tol: float = 10.0) -> pd.DataFrame:
    rows = []
    for k, g in df.groupby(by):
        m = point_metrics(g["y_true"], g["y_pred"], tol); m[by] = k; m["n"] = len(g); rows.append(m)
    return pd.DataFrame(rows).set_index(by)
