"""Evaluation orchestrator: reads a trained scenario's predictions, recomputes baselines, writes metrics, charts and the executive summary."""
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from agriyield.config import SCENARIOS                      # noqa: E402
from agriyield.features import build_features              # noqa: E402
from agrieval import metrics as M, scorecard as S, visuals as V   # noqa: E402
from agrieval.config import EvalPolicy                      # noqa: E402

SEGMENT = {"crop_yield": "crop", "dairy_milk": "breed"}


def load_eval_frame(scenario: str, base="outputs") -> pd.DataFrame:
    sc = SCENARIOS[scenario]
    raw = pd.read_csv(ROOT / base / scenario / "dataset.csv")
    df, _ = build_features(raw, sc)
    lag1, roll = f"{sc.target}_lag1", f"{sc.target}_roll{sc.roll_window}"
    test = df[(df[sc.time_col] > sc.dev_end) & df[lag1].notna()]
    pred = pd.read_csv(ROOT / base / scenario / "test_predictions.csv")
    keys = sc.entity_cols + [sc.time_col]
    out = test.merge(pred[keys + ["y_pred", "lo", "hi"]], on=keys, how="inner")
    out = out.rename(columns={sc.target: "y_true", lag1: "naive_last", roll: "naive_roll"})
    out["entity"] = out[sc.entity_cols].astype(str).agg(" / ".join, axis=1)
    return out


def evaluate(scenario: str, base="outputs", pol: EvalPolicy | None = None, verbose=True) -> dict:
    pol = pol or EvalPolicy()
    sc = SCENARIOS[scenario]
    out_dir = ROOT / base / "evaluation" / scenario
    (out_dir / "figures").mkdir(parents=True, exist_ok=True)
    df = load_eval_frame(scenario, base)
    seg = SEGMENT[scenario]; grp = sc.group_col; tcol = sc.time_col

    # ---- 1. point metrics for model and baselines ----
    cand = {"Model (AgriYield ensemble)": "y_pred", "Simple rule: same as last period": "naive_last", f"Simple rule: {sc.roll_window}-period average": "naive_roll"}
    rows = {}
    for lab, col in cand.items():
        m = M.point_metrics(df.y_true, df[col], pol.tolerance_pct)
        m["MASE"] = M.mase(df.y_true, df[col], df.naive_last); m.update(M.calibration_fit(df.y_true, df[col]))
        m["BusinessCost"] = M.asymmetric_cost(df.y_true, df[col], pol.under_cost, pol.over_cost)
        rows[lab] = m
    table = pd.DataFrame(rows).T
    mod = rows["Model (AgriYield ensemble)"]
    ref = rows["Simple rule: same as last period"]
    mod["Skill"] = M.skill(mod["RMSE"], ref["RMSE"])
    table["Skill_vs_last"] = [M.skill(r["RMSE"], ref["RMSE"]) for r in rows.values()]

    # ---- 2. uncertainty of the metrics (cluster bootstrap) ----
    ci = {}
    for name, fn in {"RMSE": lambda d: np.sqrt(np.mean((d.y_pred - d.y_true) ** 2)),
                     "MAPE": lambda d: np.mean(np.abs(d.y_pred - d.y_true) / d.y_true) * 100,
                     "R2": lambda d: 1 - np.sum((d.y_true - d.y_pred) ** 2) / np.sum((d.y_true - d.y_true.mean()) ** 2),
                     "Skill": lambda d: 1 - np.sqrt(np.mean((d.y_pred - d.y_true) ** 2)) / np.sqrt(np.mean((d.naive_last - d.y_true) ** 2))}.items():
        lo, hi, _ = M.cluster_bootstrap(df, fn, grp, pol.n_boot, pol.seed)
        ci[name] = (lo, hi)
    d_est, d_lo, d_hi, d_p = M.paired_bootstrap_diff(df, "y_pred", "naive_last", grp, pol.n_boot, pol.seed)

    # ---- 3. interval quality ----
    im = M.interval_metrics(df.y_true, df.lo, df.hi)
    mod.update(im)
    cov_by = df.assign(c=(df.y_true >= df.lo) & (df.y_true <= df.hi)).groupby(seg)["c"].mean()

    # ---- 4. shortfall early-warning ----
    thr = pol.shortfall_ratio * df.naive_roll
    actual_ev = (df.y_true < thr).values
    det_model = M.detection_metrics(actual_ev, (df.y_pred < thr).values)
    det_naive = M.detection_metrics(actual_ev, (df.naive_last < thr).values)
    mod.update({k: det_model[k] for k in ("Precision", "Recall", "F1")})

    # ---- 5. segments ----
    seg_tab = M.segment_metrics(df, seg, pol.tolerance_pct)
    grp_tab = M.segment_metrics(df, grp, pol.tolerance_pct)
    per_tab = M.segment_metrics(df, tcol, pol.tolerance_pct)
    ent_tab = M.segment_metrics(df, "entity", pol.tolerance_pct)
    rank = M.rank_agreement(df, tcol)
    mod["RankAgreement"] = rank
    cost_saving = 1 - mod["BusinessCost"] / ref["BusinessCost"]

    # ---- 6. scorecard + summary ----
    card = S.build_scorecard({**mod}, pol)
    status = S.overall_status(card)
    best, worst = seg_tab["MAPE"].idxmin(), seg_tab["MAPE"].idxmax()
    recs, cav = _recommendations(mod, seg_tab, per_tab, pol, seg, sc, cov_by)
    extras = dict(n=len(df), period=f"{sc.time_col} {int(df[tcol].min())} to {int(df[tcol].max())}", skill_ci=ci["Skill"],
                  cost_saving=cost_saving, best_segment=(best, seg_tab.loc[best, "MAPE"]), worst_segment=(worst, seg_tab.loc[worst, "MAPE"]),
                  recommendations=recs, caveats=cav)
    summary_md = S.executive_summary(sc.description.split(" (")[0].rstrip("."), sc.target_unit, mod, card, pol, extras)

    # ---- 7. figures ----
    fg = out_dir / "figures"
    V.scorecard(card, status, "Model report card", fg / "01_scorecard.png")
    cmp_ = pd.DataFrame({"RMSE": table["RMSE"]}); cmp_["lo"], cmp_["hi"] = np.nan, np.nan
    cmp_.loc["Model (AgriYield ensemble)", ["lo", "hi"]] = ci["RMSE"]
    V.model_vs_baselines(cmp_, sc.target_unit, fg / "02_model_vs_simple_rules.png")
    V.typical_miss(seg_tab, seg, pol.tolerance_pct, fg / "03_typical_miss_by_segment.png")
    V.actual_vs_forecast(df, sc.target_unit, pol.tolerance_pct, fg / "04_actual_vs_forecast.png")
    V.error_spread(df, pol.tolerance_pct, fg / "05_error_spread.png")
    V.over_under_by_period(df, tcol, fg / "06_over_under_by_period.png")
    ent_sorted = ent_tab.sort_values("MAPE")
    picks = [(i, "best") for i in ent_sorted.index[:3]] + [(i, "hardest") for i in ent_sorted.index[-3:]]
    V.small_multiples(df, "entity", tcol, sc.target_unit, picks, fg / "07_best_and_hardest_cases.png")
    V.shortfall_chart({"Model": det_model, "Simple rule (last period)": det_naive}, fg / "08_shortfall_warning.png")
    V.cost_chart({k: v["BusinessCost"] for k, v in rows.items()}, fg / "09_planning_cost.png")
    V.range_reliability(cov_by, 0.90, fg / "10_range_reliability.png")

    # ---- 8. persist ----
    table.round(4).to_csv(out_dir / "metrics_model_vs_baselines.csv")
    seg_tab.round(4).to_csv(out_dir / f"metrics_by_{seg}.csv"); per_tab.round(4).to_csv(out_dir / f"metrics_by_{tcol}.csv")
    grp_tab.round(4).to_csv(out_dir / f"metrics_by_{grp}.csv")
    (out_dir / "executive_summary.md").write_text(summary_md)
    res = dict(scenario=scenario, status=status, n=len(df), model=mod, baseline_last=ref, baseline_roll=rows[list(rows)[2]],
               ci={k: list(v) for k, v in ci.items()}, paired_rmse_diff=dict(estimate=d_est, lo=d_lo, hi=d_hi, p=d_p),
               detection_model=det_model, detection_naive=det_naive, cost_saving=cost_saving,
               coverage_by_segment=cov_by.round(3).to_dict(), scorecard=[list(r) for r in card],
               best_segment=best, worst_segment=worst, recommendations=recs, caveats=cav)
    json.dump(res, open(out_dir / "evaluation_summary.json", "w"), indent=2, default=float)
    if verbose:
        print(f"[{scenario}] status={status} MAPE={mod['MAPE']:.1f}% skill={mod['Skill']:.2f} coverage={mod['Coverage']:.2f} recall={mod['Recall']:.2f} costsaving={cost_saving:.2f}")
    return res


def _recommendations(m, seg_tab, per_tab, pol, seg, sc, cov_by=None):
    t, r, c = pol.thresholds, [], []
    if abs(m["BiasPct"]) > t.bias_green:
        side = "under" if m["Bias"] < 0 else "over"
        r.append(f"Correct the systematic {side}-forecast ({m['BiasPct']:+.1f}%): add a trend-adjusted target or retrain every season on the newest data, then re-check the bias.")
    if m["Coverage"] < t.coverage_green:
        r.append(f"Recalibrate the 90% range (currently covers {m['Coverage']*100:.0f}%) using the most recent seasons' errors so that planners can rely on it.")
    if cov_by is not None and cov_by.min() < 0.90 - 0.12:
        lo_s, hi_s = cov_by.idxmin(), cov_by.idxmax()
        r.append(f"The forecast range is uneven across {seg}s ({lo_s}: {cov_by.min()*100:.0f}% covered vs {hi_s}: {cov_by.max()*100:.0f}%): switch to ranges calibrated separately per {seg} (or proportional to the forecast).")
    worst = seg_tab["MAPE"].idxmax()
    if seg_tab.loc[worst, "MAPE"] > pol.tolerance_pct:
        r.append(f"Investigate the weakest segment ({seg}: {worst}, {seg_tab.loc[worst, 'MAPE']:.1f}% error): collect better inputs or fit a segment-specific model.")
    if m["Recall"] < t.recall_green:
        r.append(f"Improve early warning (catches {m['Recall']*100:.0f}% of shortfalls): tune the alert threshold on cost, or add in-season indicators.")
    if per_tab["MAPE"].iloc[-1] > per_tab["MAPE"].iloc[0] * 1.15:
        r.append("Errors are rising in the latest period; schedule a drift review before the next planning cycle.")
    r.append("Validate on real field data and extend the test window to at least five seasons before committing budget decisions.")
    c.append("Results come from a limited number of test periods; confidence ranges are shown for this reason.")
    c.append("Forecast quality describes association, not cause: the model should support, not replace, local expertise.")
    c.append("Cost figures use relative weights (shortfall = %.0fx surplus) that must be confirmed with the business." % pol.under_cost)
    return r, c


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument("--scenario", default="all"); ap.add_argument("--base", default="outputs")
    a = ap.parse_args()
    for s in (["crop_yield", "dairy_milk"] if a.scenario == "all" else [a.scenario]):
        evaluate(s, a.base)
