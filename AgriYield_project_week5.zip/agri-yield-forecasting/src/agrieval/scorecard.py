"""Traffic-light scorecard and auto-generated plain-language executive summary."""
from __future__ import annotations
from typing import Dict, List, Tuple
from .config import EvalPolicy

G, A, R = "GREEN", "AMBER", "RED"


def _hi_good(v, g, a):  # higher is better
    return G if v >= g else A if v >= a else R


def _lo_good(v, g, a):  # lower is better
    return G if v <= g else A if v <= a else R


def build_scorecard(m: Dict[str, float], pol: EvalPolicy) -> List[Tuple[str, str, str, str]]:
    """returns rows: (question, value text, status, plain-language meaning)."""
    t = pol.thresholds
    rows = [
        ("How big is a typical miss?", f"{m['MAPE']:.1f}% (MAPE)", _lo_good(m["MAPE"], t.mape_green, t.mape_amber),
         f"On average the forecast is {m['MAPE']:.0f}% away from the actual value."),
        ("Is it better than the simple rule?", f"{m['Skill']*100:.0f}% fewer errors", _hi_good(m["Skill"], t.skill_green, t.skill_amber),
         "Compared with 'same as last season', the model cuts the error by this much."),
        (f"How often is it usable (within +/-{pol.tolerance_pct:.0f}%)?", f"{m['WithinTol']*100:.0f}% of forecasts", _hi_good(m["WithinTol"], t.within_tol_green, t.within_tol_amber),
         "Share of forecasts close enough to plan stock, transport and cash with."),
        ("Does it lean high or low?", f"{m['BiasPct']:+.1f}% bias", _lo_good(abs(m["BiasPct"]), t.bias_green, t.bias_amber),
         "Negative = tends to under-forecast (risk of stock-outs); positive = over-forecast (risk of surplus)."),
        ("Can we trust the range?", f"{m['Coverage']*100:.0f}% inside the 90% range", _hi_good(m["Coverage"], t.coverage_green, t.coverage_amber),
         "The stated range should contain the real outcome about 9 times in 10."),
    ]
    if m.get("Recall") == m.get("Recall") and m.get("Recall") is not None:
        rows.append(("Does it warn us of bad seasons?", f"{m['Recall']*100:.0f}% of shortfalls caught", _hi_good(m["Recall"], t.recall_green, t.recall_amber),
                     "Share of genuinely poor outcomes that the model flagged in advance."))
    return rows


def overall_status(rows) -> str:
    """Overall rule (documented in the report): RED if a core accuracy check (error size or skill vs naive)
    is red, or if two or more checks are red; AMBER if any check is red/amber; otherwise GREEN."""
    s = [r[2] for r in rows]
    core = [rows[0][2], rows[1][2]]
    if R in core or s.count(R) >= 2:
        return R
    return A if (R in s or A in s) else G


def executive_summary(name: str, unit: str, m: Dict[str, float], rows, pol: EvalPolicy, extras: Dict) -> str:
    st = overall_status(rows)
    verdict = {G: "ready for operational use", A: "usable for planning, provided the safeguards listed under Recommendations are put in place", R: "not yet ready for operational use"}[st]
    worst = extras.get("worst_segment")
    best = extras.get("best_segment")
    lines = [
        f"# Executive summary: {name}", "",
        f"**Overall verdict: {st}. The model is {verdict}.**", "",
        "## What we measured",
        f"The model forecast {extras['n']:,} outcomes that it had never seen ({extras['period']}). Its results were compared with the simple rule 'next value = last value'.", "",
        "## Headline findings",
        f"- A typical forecast is **{m['MAPE']:.1f}% away** from the actual value (average miss {m['MAE']:.2f} {unit}).",
        f"- **{m['Skill']*100:.0f}% fewer errors** than the simple rule (95% confidence range {extras['skill_ci'][0]*100:.0f}% to {extras['skill_ci'][1]*100:.0f}%).",
        f"- **{m['WithinTol']*100:.0f}%** of forecasts landed within +/-{pol.tolerance_pct:.0f}% of the real value.",
        f"- The model {'under' if m['Bias'] < 0 else 'over'}-forecasts by {abs(m['BiasPct']):.1f}% on average.",
        f"- The stated 90% range contained the real value {m['Coverage']*100:.0f}% of the time.",
    ]
    if extras.get("cost_saving") is not None:
        lines.append(f"- Using the agreed cost weights (a shortfall costs {pol.under_cost:.0f}x a surplus), planning with the model costs **{extras['cost_saving']*100:.0f}% less** than planning with the simple rule.")
    if m.get("Recall") == m.get("Recall") and m.get("Recall") is not None:
        lines.append(f"- It flagged **{m['Recall']*100:.0f}%** of the genuine shortfall cases in advance; {m['Precision']*100:.0f}% of its warnings were correct.")
    if best and worst:
        lines.append(f"- Most accurate for **{best[0]}** ({best[1]:.1f}% error); least accurate for **{worst[0]}** ({worst[1]:.1f}% error).")
    lines += ["", "## Scorecard", "| Question | Result | Status |", "|---|---|---|"]
    lines += [f"| {q} | {v} | {s} |" for q, v, s, _ in rows]
    lines += ["", "## Recommendations"] + [f"{i+1}. {r}" for i, r in enumerate(extras["recommendations"])]
    lines += ["", "## Caveats", "- " + "\n- ".join(extras["caveats"])]
    return "\n".join(lines)
