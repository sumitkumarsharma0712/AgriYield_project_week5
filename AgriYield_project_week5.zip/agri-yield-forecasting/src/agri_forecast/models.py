"""Model zoo: baselines, tuned ML candidates and a simple averaging ensemble."""
from __future__ import annotations

from typing import Callable, Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy.stats import loguniform
from sklearn.base import BaseEstimator, RegressorMixin, clone
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


# --------------------------------------------------------------------------- #
# Baselines (no learning): every ML model has to beat these to be worth deploying
# --------------------------------------------------------------------------- #
class NaiveLastValue(BaseEstimator, RegressorMixin):
    """Forecast = previous period's value of the same entity."""

    def __init__(self, lag_col: str):
        self.lag_col = lag_col

    def fit(self, X, y):
        self.fallback_ = float(np.nanmean(y))
        return self

    def predict(self, X):
        return X[self.lag_col].fillna(self.fallback_).to_numpy()


class MovingAverage(NaiveLastValue):
    """Forecast = shifted rolling mean of the entity's own history."""


class SegmentMean(BaseEstimator, RegressorMixin):
    """Forecast = training mean of the segment (e.g. crop)."""

    def __init__(self, segment_col: str):
        self.segment_col = segment_col

    def fit(self, X, y):
        s = pd.Series(np.asarray(y), index=X.index)
        self.means_ = s.groupby(X[self.segment_col]).mean().to_dict()
        self.global_ = float(s.mean())
        return self

    def predict(self, X):
        return X[self.segment_col].map(self.means_).fillna(self.global_).to_numpy()


# --------------------------------------------------------------------------- #
# Pre-processing + estimator pipelines
# --------------------------------------------------------------------------- #
def build_pipeline(estimator, numeric: Sequence[str], categorical: Sequence[str], scale: bool) -> Pipeline:
    num = Pipeline([("imp", SimpleImputer(strategy="median")),
                    ("sc", StandardScaler() if scale else "passthrough")])
    transformers = []
    if numeric:
        transformers.append(("num", num, list(numeric)))
    if categorical:
        transformers.append(("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), list(categorical)))
    return Pipeline([("prep", ColumnTransformer(transformers)), ("model", estimator)])


def model_zoo(seed: int = 42) -> Dict[str, dict]:
    """name -> dict(make=callable(estimator-free kwargs), scale, dist)."""
    return {
        "Ridge": dict(
            est=lambda: Ridge(), scale=True,
            dist={"model__alpha": loguniform(1e-2, 1e2)}),
        "Random Forest": dict(
            est=lambda: RandomForestRegressor(random_state=seed, n_jobs=-1), scale=False,
            dist={"model__n_estimators": [150, 250, 400],
                  "model__max_depth": [None, 8, 12, 16],
                  "model__min_samples_leaf": [1, 2, 4, 8],
                  "model__max_features": [0.4, 0.6, 0.8, 1.0]}),
        "Extra Trees": dict(
            est=lambda: ExtraTreesRegressor(random_state=seed, n_jobs=-1), scale=False,
            dist={"model__n_estimators": [150, 250, 400],
                  "model__max_depth": [None, 8, 12, 16],
                  "model__min_samples_leaf": [1, 2, 4, 8],
                  "model__max_features": [0.4, 0.6, 0.8, 1.0]}),
        "Gradient Boosting": dict(
            est=lambda: HistGradientBoostingRegressor(random_state=seed), scale=False,
            dist={"model__learning_rate": loguniform(0.02, 0.2),
                  "model__max_iter": [200, 400, 600],
                  "model__max_depth": [3, 5, None],
                  "model__max_leaf_nodes": [15, 31],
                  "model__min_samples_leaf": [10, 20, 40],
                  "model__l2_regularization": loguniform(1e-3, 10)}),
    }


class AveragingEnsemble(BaseEstimator, RegressorMixin):
    """Unweighted mean of several (unfitted) pipelines; clones and fits each on ``fit``."""

    def __init__(self, estimators: List[Pipeline]):
        self.estimators = estimators

    def fit(self, X, y):
        self.fitted_ = [clone(e).fit(X, y) for e in self.estimators]
        return self

    def predict(self, X):
        return np.mean([m.predict(X) for m in self.fitted_], axis=0)


Factory = Callable[[Sequence[str], Sequence[str]], BaseEstimator]
