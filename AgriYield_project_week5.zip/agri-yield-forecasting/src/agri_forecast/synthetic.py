"""Synthetic data generators for the two demonstration scenarios.

IMPORTANT: no real farm data was available for this task, so both datasets are
*simulated*. They are generated from agronomically motivated response functions
(rainfall/irrigation optimum, heat stress, nitrogen response, soil quality, pest
pressure, technology trend, autocorrelated shocks, measurement noise and missing
values). They exist to exercise and validate the framework end-to-end; the
numbers they produce must NOT be read as real agronomic findings. Replace the
generator with ``pd.read_csv(...)`` of real data (same column schema) to use the
framework in production.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------- #
# Scenario 1: seasonal crop yield per region x crop x year
# --------------------------------------------------------------------------- #
CROPS = {
    #            base  rain_share opt_water irr_mm heat  dry  n_resp n_scale fert  irr0  pest  tmax_off hybrid
    "Wheat":   dict(base=2.8, share=0.15, opt=450,  irr=400, heat=1.3, dry=0.6, n_resp=0.40, n_scale=85, fert=110, irr0=0.75, pest=0.7, off=-6.0, hyb=0.08),
    "Rice":    dict(base=3.1, share=1.00, opt=1100, irr=400, heat=0.8, dry=1.0, n_resp=0.35, n_scale=80, fert=100, irr0=0.55, pest=1.0, off=-2.0, hyb=0.12),
    "Cotton":  dict(base=1.7, share=0.90, opt=800,  irr=250, heat=0.9, dry=0.9, n_resp=0.30, n_scale=70, fert=90,  irr0=0.30, pest=1.4, off=0.0,  hyb=0.15),
    "Soybean": dict(base=1.2, share=0.80, opt=650,  irr=150, heat=0.7, dry=1.1, n_resp=0.12, n_scale=30, fert=25,  irr0=0.10, pest=1.1, off=-1.0, hyb=0.10),
}
ZONES = {
    "Dry":        dict(rain=650,  tmax=34.0, hum=50),
    "Semi-humid": dict(rain=950,  tmax=32.0, hum=62),
    "Humid":      dict(rain=1250, tmax=30.0, hum=74),
}


def generate_crop_yield(seed: int = 42, n_regions: int = 20,
                        start_year: int = 2006, end_year: int = 2024) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    years = np.arange(start_year, end_year + 1)
    regions = [f"R{i:02d}" for i in range(1, n_regions + 1)]
    zone_names = list(ZONES)
    zone_of = rng.choice(zone_names, size=n_regions, p=[0.30, 0.45, 0.25])

    # region-level static attributes
    reg = {}
    for r, z in zip(regions, zone_of):
        zp = ZONES[z]
        reg[r] = dict(
            zone=z,
            rain=zp["rain"] * rng.uniform(0.9, 1.1),
            tmax=zp["tmax"] + rng.normal(0, 0.6),
            hum=zp["hum"] + rng.normal(0, 3),
            ph=float(np.clip(rng.normal(7.1 if z == "Dry" else 6.6, 0.4), 5.5, 8.3)),
            oc=float(np.clip(rng.normal(0.55, 0.15), 0.2, 1.2)),
            soil_n=float(rng.normal(210, 40)),
            elev=float(rng.uniform(250, 700)),
        )

    # region-year shared climate shocks (crops in the same region/year co-move)
    z_rain = {(r, y): rng.normal() for r in regions for y in years}
    z_temp = {k: -0.5 * v + np.sqrt(0.75) * rng.normal() for k, v in z_rain.items()}

    rows = []
    for r in regions:
        R = reg[r]
        for crop, C in CROPS.items():
            fert0 = C["fert"] * rng.uniform(0.85, 1.15)
            irr0 = float(np.clip(C["irr0"] + rng.normal(0, 0.12), 0.02, 0.98))
            area0 = rng.uniform(8, 60)  # thousand ha
            re = rng.normal(0, 0.07)    # region x crop random effect
            e_prev = 0.0
            area = area0
            rain_mean_season = R["rain"] * C["share"]
            for y in years:
                t = y - start_year
                zr, zt = z_rain[(r, y)], z_temp[(r, y)]
                s = 0.22
                rain = rain_mean_season * np.exp(s * zr - 0.5 * s ** 2 + rng.normal(0, 0.05))
                anom_t = 0.9 * zt + 0.035 * t
                tmax = R["tmax"] + C["off"] + anom_t + rng.normal(0, 0.25)
                diurnal = 11 - 0.05 * R["hum"] + rng.normal(0, 0.8)
                tmin = tmax - diurnal
                hum = float(np.clip(R["hum"] + 15 * (rain / rain_mean_season - 1) + rng.normal(0, 3), 25, 95))
                solar = 18 - 4 * (rain / rain_mean_season - 1) + rng.normal(0, 0.8)
                heat_days = rng.poisson(max(0.3, 4 + 4.0 * anom_t + 0.5 * (R["tmax"] - 32)))
                dry_spell = float(np.clip(rng.gamma(2.0, 3.5) * (rain_mean_season / rain) ** 0.8, 0, 40))
                irr_frac = float(np.clip(irr0 + 0.006 * t + rng.normal(0, 0.03), 0.0, 1.0))
                fert = float(max(5.0, fert0 * (1 + 0.012 * t) + rng.normal(0, 5)))
                hybrid = float(np.clip(1 / (1 + np.exp(-(t - 8) / 3.5)) + rng.normal(0, 0.03), 0, 1))
                pest = float(np.clip(0.25 + 0.5 * (hum - 60) / 40 + rng.normal(0, 0.12), 0, 1))
                area = float(max(2.0, area * (1 + rng.normal(0, 0.03))))

                # ---- response functions (the hidden "truth") ----
                eff_water = rain + irr_frac * C["irr"]
                # asymmetric response: water deficit hurts more than moderate excess
                width = (0.35 if eff_water < C["opt"] else 0.80) * C["opt"]
                w = np.exp(-0.5 * ((eff_water - C["opt"]) / width) ** 2)
                h = 1 - C["heat"] * 0.011 * heat_days
                d = 1 - C["dry"] * 0.009 * dry_spell
                f = 1 + C["n_resp"] * (1 - np.exp(-fert / C["n_scale"]))
                sf = 1 + 0.07 * (R["oc"] - 0.6) / 0.3 - 0.05 * abs(R["ph"] - 6.8)
                p = 1 - 0.18 * pest * C["pest"]
                hy = 1 + C["hyb"] * hybrid
                tech = 1 + 0.008 * t
                e = 0.5 * e_prev + rng.normal(0, 0.045)
                e_prev = e
                stress = max(w * h * d * p, 0.0)
                yld = C["base"] * tech * w * h * d * f * sf * p * hy * np.exp(re + e)
                yld = float(max(yld, 0.1))
                ndvi = float(np.clip(0.30 + 0.45 * min(stress * sf, 1.2) + rng.normal(0, 0.03), 0.2, 0.92))

                rows.append(dict(
                    region=r, crop=crop, year=int(y), agro_zone=R["zone"], elevation_m=R["elev"],
                    rainfall_mm=rain, tmax_mean_c=tmax, tmin_mean_c=tmin, humidity_pct=hum,
                    solar_rad_mj=solar, dry_spell_days=dry_spell, heat_stress_days=float(heat_days),
                    soil_ph=R["ph"] + rng.normal(0, 0.05), soil_oc_pct=R["oc"] + rng.normal(0, 0.02),
                    soil_n_kg_ha=R["soil_n"] + rng.normal(0, 6),
                    fert_n_kg_ha=fert, irrigated_frac=irr_frac, hybrid_frac=hybrid,
                    pest_index=pest, ndvi_peak=ndvi, area_kha=area, yield_t_ha=yld,
                ))

    df = pd.DataFrame(rows)

    # realistic data issues: random missing values in sensor / lab-derived columns
    for col, rate in [("ndvi_peak", 0.06), ("soil_n_kg_ha", 0.03), ("humidity_pct", 0.03)]:
        mask = rng.random(len(df)) < rate
        df.loc[mask, col] = np.nan
    return df


def derive_crop_features(df: pd.DataFrame) -> pd.DataFrame:
    """Domain-driven derived features for the crop scenario (row-wise, no leakage)."""
    out = df.copy()
    out["diurnal_range_c"] = out["tmax_mean_c"] - out["tmin_mean_c"]
    out["water_index_mm"] = out["rainfall_mm"] + 300.0 * out["irrigated_frac"]
    out["heat_dry_stress"] = out["heat_stress_days"] + out["dry_spell_days"]
    out["n_x_irrigation"] = out["fert_n_kg_ha"] * out["irrigated_frac"]
    return out


# --------------------------------------------------------------------------- #
# Scenario 2: monthly milk yield per farm (demonstrates universality)
# --------------------------------------------------------------------------- #
BREEDS = {
    "HF_cross":      dict(base=16.0, heat=1.00, conc0=4.5),
    "Jersey_cross":  dict(base=13.0, heat=0.80, conc0=4.0),
    "Gir_cross":     dict(base=8.5,  heat=0.35, conc0=2.5),
    "Sahiwal_cross": dict(base=9.5,  heat=0.40, conc0=2.8),
}


def generate_dairy_milk(seed: int = 7, n_farms: int = 40, months: int = 72) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    clusters = [f"C{i}" for i in range(1, 6)]
    cl_temp = dict(zip(clusters, rng.normal(26.5, 1.4, size=len(clusters))))
    rows = []
    breed_names = list(BREEDS)
    for i in range(1, n_farms + 1):
        farm = f"F{i:03d}"
        cl = clusters[(i - 1) % len(clusters)]
        breed = breed_names[int(rng.integers(0, len(breed_names)))]
        B = BREEDS[breed]
        housing = rng.choice(["free_stall", "tie_stall"], p=[0.4, 0.6])
        herd0 = float(rng.uniform(10, 120))
        dist = float(rng.uniform(2, 60))
        conc0 = B["conc0"] * rng.uniform(0.8, 1.2)
        green0 = rng.uniform(10, 24)
        dry0 = rng.uniform(4, 8)
        re = rng.normal(0, 0.09)
        dim = float(rng.normal(170, 25))
        e_prev = 0.0
        for m in range(1, months + 1):
            month = (m - 1) % 12 + 1
            year = 2019 + (m - 1) // 12
            temp = cl_temp[cl] + 6.0 * np.sin(2 * np.pi * (month - 1) / 12) + 0.04 * (m / 12) + rng.normal(0, 0.9)
            hum = float(np.clip(58 + 22 * np.sin(2 * np.pi * (month - 5) / 12) + rng.normal(0, 4), 25, 97))
            thi = 0.8 * temp + hum / 100 * (temp - 14.4) + 46.4
            herd = herd0 * (1 + 0.004 * m) * np.exp(rng.normal(0, 0.01))
            dim = float(np.clip(0.9 * dim + 0.1 * 170 + rng.normal(0, 8), 80, 320))
            parity = float(np.clip(2.6 + rng.normal(0, 0.15), 1.5, 4.5))
            conc = float(max(0.5, conc0 * (1 + 0.003 * m) + rng.normal(0, 0.25)))
            green = float(max(1.0, green0 * (1 + 0.35 * np.sin(2 * np.pi * (month - 6) / 12)) + rng.normal(0, 1.2)))
            dryf = float(max(1.0, dry0 + rng.normal(0, 0.5)))
            mast = float(np.clip(0.05 + 0.0006 * (hum - 60) + rng.normal(0, 0.02), 0.0, 0.3))
            vet = float(rng.poisson(1.5))

            f_dim = float(np.clip(1.12 - 0.35 * ((dim - 100) / 150) ** 2, 0.5, 1.2))
            heat = 1 - 0.014 * B["heat"] * max(0.0, thi - 72)
            feed = 1 + 0.30 * (1 - np.exp(-conc / 3.0))
            fod = 1 + 0.08 * (1 - np.exp(-green / 12))
            mst = 1 - 1.1 * mast
            hrd = 1 + 0.02 * np.log(herd / 30)
            e = 0.6 * e_prev + rng.normal(0, 0.04)
            e_prev = e
            y = B["base"] * f_dim * heat * feed * fod * mst * hrd * np.exp(re + e + rng.normal(0, 0.035))
            rows.append(dict(
                farm_id=farm, cluster=cl, breed=breed, housing=housing, month_idx=m, month=month, year=year,
                distance_to_market_km=dist, herd_size=herd, mean_dim=dim, avg_parity=parity,
                conc_feed_kg=conc, green_fodder_kg=green, dry_fodder_kg=dryf,
                temp_c=temp, humidity_pct=hum, mastitis_rate=mast, vet_visits=vet,
                milk_l_per_cow_day=float(max(y, 0.5)),
            ))
    df = pd.DataFrame(rows)
    for col, rate in [("mastitis_rate", 0.04), ("green_fodder_kg", 0.03), ("humidity_pct", 0.02)]:
        mask = rng.random(len(df)) < rate
        df.loc[mask, col] = np.nan
    return df


def derive_dairy_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    hum = out["humidity_pct"].fillna(out["humidity_pct"].median())
    out["thi"] = 0.8 * out["temp_c"] + hum / 100 * (out["temp_c"] - 14.4) + 46.4
    out["thi_excess"] = (out["thi"] - 72).clip(lower=0)
    out["total_dm_feed_kg"] = out["conc_feed_kg"] + out["dry_fodder_kg"] + 0.25 * out["green_fodder_kg"].fillna(out["green_fodder_kg"].median())
    return out
