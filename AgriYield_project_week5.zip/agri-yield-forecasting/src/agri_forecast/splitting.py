"""Time-aware data splitting. Random shuffling is never used: it would let the
model train on the future and grossly overstate accuracy."""
from __future__ import annotations

from typing import List, Tuple

import numpy as np
import pandas as pd

from .config import ScenarioConfig


def temporal_holdout(df: pd.DataFrame, cfg: ScenarioConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Last ``test_periods`` periods -> untouched test set; everything earlier -> development set."""
    periods = np.sort(df[cfg.time_col].unique())
    test_p = periods[-cfg.test_periods:]
    is_test = df[cfg.time_col].isin(test_p)
    return df[~is_test].reset_index(drop=True), df[is_test].reset_index(drop=True)


def expanding_window_splits(time_values, n_folds: int, block: int) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Expanding-window (forward-chaining) CV.

    Fold k trains on all periods before a validation block of ``block`` periods; the
    blocks are the last ``n_folds * block`` periods of the development set, in order.
    Returns positional index arrays compatible with scikit-learn ``cv=``.
    """
    time_values = np.asarray(time_values)
    periods = np.sort(np.unique(time_values))
    if len(periods) - n_folds * block < 3:
        raise ValueError("not enough periods: the first CV fold would train on fewer than 3 periods")
    splits = []
    for k in range(n_folds):
        end = len(periods) - (n_folds - 1 - k) * block
        start = end - block
        val_p, train_p = periods[start:end], periods[:start]
        tr = np.where(np.isin(time_values, train_p))[0]
        va = np.where(np.isin(time_values, val_p))[0]
        splits.append((tr, va))
    return splits


def describe_split(dev: pd.DataFrame, test: pd.DataFrame, cfg: ScenarioConfig) -> dict:
    return {
        "dev_periods": [int(dev[cfg.time_col].min()), int(dev[cfg.time_col].max())],
        "test_periods": [int(test[cfg.time_col].min()), int(test[cfg.time_col].max())],
        "n_dev": int(len(dev)),
        "n_test": int(len(test)),
    }
