"""Leakage-safe, scenario-agnostic feature engineering.

Every history-based feature at time *t* is built from information at times
strictly earlier than *t* (``shift(1)`` before any rolling/expanding statistic),
so a row can never see its own target or any future value.
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Dict, List

import numpy as np
import pandas as pd

from .config import ScenarioConfig


@dataclass
class FeatureSpec:
    numeric: List[str]
    categorical: List[str]
    groups: Dict[str, List[str]]

    @property
    def all(self) -> List[str]:
        return self.numeric + self.categorical


def _check_regular_panel(df: pd.DataFrame, cfg: ScenarioConfig) -> None:
    """Lags assume consecutive periods per entity; warn if the panel has gaps."""
    g = df.groupby(cfg.entity_cols)[cfg.time_col]
    gaps = (g.diff().dropna() != 1).sum()
    if gaps:
        warnings.warn(f"{gaps} non-consecutive time steps found; lag features may be misaligned. "
                      "Reindex the panel to a complete grid before modelling.")


def engineer_features(raw: pd.DataFrame, cfg: ScenarioConfig):
    """Return (modelling table, FeatureSpec, warm-up rows dropped)."""
    df = raw.sort_values(cfg.entity_cols + [cfg.time_col]).reset_index(drop=True)
    if cfg.derive is not None:
        df = cfg.derive(df)
    _check_regular_panel(df, cfg)

    groups = {k: list(v) for k, v in cfg.feature_groups.items()}
    numeric = list(cfg.numeric)
    g = df.groupby(cfg.entity_cols, sort=False)

    # 1) target history: lags and shifted rolling means -------------------------------------
    hist: List[str] = []
    for L in cfg.lags:
        c = f"{cfg.target}_lag{L}"
        df[c] = g[cfg.target].shift(L)
        hist.append(c)
    for W in cfg.rolling_windows:
        c = f"{cfg.target}_roll{W}_mean"
        df[c] = g[cfg.target].transform(lambda s, W=W: s.shift(1).rolling(W, min_periods=1).mean())
        hist.append(c)
    # entity-level trend: last value minus the shifted rolling mean (momentum)
    if cfg.lags and cfg.rolling_windows:
        c = f"{cfg.target}_momentum"
        df[c] = df[f"{cfg.target}_lag1"] - df[f"{cfg.target}_roll{cfg.rolling_windows[0]}_mean"]
        hist.append(c)
    numeric += hist
    groups["history"] = hist

    # 2) anomalies versus the entity's own *past* climatology ---------------------------------
    for col in cfg.anomaly_cols:
        c = f"{col}_anom"
        df[c] = df[col] - g[col].transform(lambda s: s.shift(1).expanding().mean())
        numeric.append(c)
        for members in groups.values():
            if col in members:
                members.append(c)
                break

    # 3) cyclical calendar encodings --------------------------------------------------------
    seas: List[str] = []
    for col, period in cfg.cyclical.items():
        df[f"{col}_sin"] = np.sin(2 * np.pi * df[col] / period)
        df[f"{col}_cos"] = np.cos(2 * np.pi * df[col] / period)
        seas += [f"{col}_sin", f"{col}_cos"]
    if seas:
        numeric += seas
        groups["seasonality"] = seas

    # 4) linear time index (technology / trend) ----------------------------------------------
    df["t_index"] = df[cfg.time_col] - df[cfg.time_col].min()
    numeric.append("t_index")
    groups["trend"] = ["t_index"]

    # 5) drop warm-up rows that lack the longest lag ----------------------------------------
    warm_col = f"{cfg.target}_lag{max(cfg.lags)}" if cfg.lags else None
    n0 = len(df)
    if warm_col:
        df = df[df[warm_col].notna()].reset_index(drop=True)
    dropped = n0 - len(df)

    spec = FeatureSpec(numeric=numeric, categorical=list(cfg.categorical), groups=groups)
    missing = set(spec.all) - {c for v in groups.values() for c in v}
    assert not missing, f"features without a group: {sorted(missing)}"
    return df, spec, dropped
