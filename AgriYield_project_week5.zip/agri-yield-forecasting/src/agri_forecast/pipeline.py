"""End-to-end orchestration: data -> features -> split -> tune -> select -> evaluate -> reliability."""
from __future__ import annotations

import json
import time
import warnings
from pathlib import Path
from typing import Dict

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.model_selection import GroupKFold, RandomizedSearchCV

from . import evaluation as ev
from . import plotting as pl
from .config import ScenarioConfig
from .features import engineer_features
from .models import (AveragingEnsemble, MovingAverage, NaiveLastValue, SegmentMean, build_pipeline,
                     model_zoo)
from .splitting import describe_split, expanding_window_splits, temporal_holdout

warnings.filterwarnings("ignore", category=UserWarning)


def _jsonable(o):
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (pd.Series,)):
        return o.to_dict()
    return str(o)


def _log(msg: str, verbose: bool):
    if verbose:
        print(msg, flush=True)


def _make_factory(entry: dict, params: Dict[str, object]):
    """Return f(numeric, categorical) -> fresh pipeline with the tuned hyper-parameters."""
    inner = {k.split("__", 1)[1]: v for k, v in params.items()}

    def factory(numeric, categorical):
        est = entry["est"]().set_params(**inner)
        return build_pipeline(est, numeric, categorical, entry["scale"])

    return factory


def run_scenario(cfg: ScenarioConfig, raw: pd.DataFrame, out_dir: str | Path, seed: int = 42,
                 n_iter: int = 12, n_boot: int = 2000, verbose: bool = True) -> dict:
    t0 = time.time()
    out = Path(out_dir) / cfg.name
    (out / "figures").mkdir(parents=True, exist_ok=True)
    tgt = cfg.target

    # ------------------------------------------------------------------ 1. features & split
    df, spec, dropped = engineer_features(raw, cfg)
    dev, test = temporal_holdout(df, cfg)
    split_info = describe_split(dev, test, cfg)
    n_entities = int(df.groupby(cfg.entity_cols).ngroups)
    _log(f"[{cfg.name}] rows={len(df)} (warm-up rows dropped={dropped}), entities={n_entities}, "
         f"features: {len(spec.numeric)} numeric + {len(spec.categorical)} categorical", verbose)
    _log(f"[{cfg.name}] dev periods {split_info['dev_periods']} (n={split_info['n_dev']}), "
         f"test periods {split_info['test_periods']} (n={split_info['n_test']})", verbose)

    X_dev, y_dev = dev[spec.all], dev[tgt]
    X_test, y_test = test[spec.all], test[tgt]
    splits = expanding_window_splits(dev[cfg.time_col].to_numpy(), cfg.cv_folds, cfg.cv_block)
    covered = np.zeros(len(dev), bool)
    for _, va in splits:
        covered[va] = True

    lag1, roll = f"{tgt}_lag1", f"{tgt}_roll{cfg.rolling_windows[0]}_mean"
    baselines = {
        "Naive (last period)": NaiveLastValue(lag1),
        "Moving average": MovingAverage(roll),
        f"{cfg.segment_col or 'Global'} mean": SegmentMean(cfg.segment_col) if cfg.segment_col else None,
    }
    baselines = {k: v for k, v in baselines.items() if v is not None}

    # ------------------------------------------------------------------ 2. baselines
    results, oof, test_pred = [], {}, {}

    def fold_rmse(o):
        return [ev.rmse(y_dev.iloc[va], o[va]) for _, va in splits]

    for name, est in baselines.items():
        o = np.full(len(dev), np.nan)
        for tr, va in splits:
            m = clone(est).fit(dev.iloc[tr], y_dev.iloc[tr])
            o[va] = m.predict(dev.iloc[va])
        oof[name] = o
        test_pred[name] = clone(est).fit(dev, y_dev).predict(test)

    # ------------------------------------------------------------------ 3. tuned ML models
    zoo = model_zoo(seed)
    factories, best_params = {}, {}
    for name, entry in zoo.items():
        ts = time.time()
        base = build_pipeline(entry["est"](), spec.numeric, spec.categorical, entry["scale"])
        search = RandomizedSearchCV(base, entry["dist"], n_iter=n_iter, scoring="neg_root_mean_squared_error",
                                    cv=splits, random_state=seed, n_jobs=1, refit=False)
        search.fit(X_dev, y_dev)
        best_params[name] = search.best_params_
        factories[name] = _make_factory(entry, search.best_params_)
        o = np.full(len(dev), np.nan)
        for tr, va in splits:
            o[va] = factories[name](spec.numeric, spec.categorical).fit(X_dev.iloc[tr], y_dev.iloc[tr]).predict(X_dev.iloc[va])
        oof[name] = o
        test_pred[name] = factories[name](spec.numeric, spec.categorical).fit(X_dev, y_dev).predict(X_test)
        _log(f"[{cfg.name}] tuned {name:<18} CV-RMSE={ev.rmse(y_dev[covered], o[covered]):.4f} "
             f"({time.time() - ts:.1f}s)", verbose)

    # simple averaging ensemble of the three tuned tree models
    members = ["Random Forest", "Extra Trees", "Gradient Boosting"]
    ens_name = "Ensemble (RF+ET+GB)"
    oof[ens_name] = np.mean([oof[m] for m in members], axis=0)
    test_pred[ens_name] = np.mean([test_pred[m] for m in members], axis=0)
    factories[ens_name] = lambda num, cat: AveragingEnsemble([factories[m](num, cat) for m in members])

    # ------------------------------------------------------------------ 4. comparison table
    ml_names = list(zoo) + [ens_name]
    for name in list(baselines) + ml_names:
        o = oof[name]
        tm = ev.regression_metrics(y_test, test_pred[name])
        fr = fold_rmse(o)
        results.append({
            "Model": name, "Type": "Baseline" if name in baselines else "ML",
            "CV_RMSE": ev.rmse(y_dev[covered], o[covered]), "CV_fold_std": float(np.std(fr)),
            "CV_MAE": float(np.mean(np.abs(y_dev[covered] - o[covered]))),
            "Test_RMSE": tm["RMSE"], "Test_MAE": tm["MAE"], "Test_R2": tm["R2"], "Test_MAPE_%": tm["MAPE_%"],
        })
    table = pd.DataFrame(results)
    selected = table[table["Type"] == "ML"].sort_values("CV_RMSE").iloc[0]["Model"]   # chosen on CV only
    best_baseline = table[table["Type"] == "Baseline"].sort_values("CV_RMSE").iloc[0]["Model"]
    table["Selected"] = table["Model"] == selected
    table.to_csv(out / "model_comparison.csv", index=False)
    _log(f"[{cfg.name}] selected model (lowest CV RMSE): {selected}", verbose)

    # ------------------------------------------------------------------ 5. final model & hold-out evaluation
    factory = factories[selected]
    final = factory(spec.numeric, spec.categorical).fit(X_dev, y_dev)
    p_test = test_pred[selected]
    test = test.assign(prediction=p_test, error=p_test - y_test.to_numpy())
    metrics = ev.regression_metrics(y_test, p_test)
    naive_name = "Naive (last period)"
    metrics["skill_vs_naive"] = ev.skill_score(y_test, p_test, test_pred[naive_name])
    metrics["skill_vs_best_baseline"] = ev.skill_score(y_test, p_test, test_pred[best_baseline])

    clusters = test[cfg.entity_cols].astype(str).agg("|".join, axis=1)
    boot = ev.cluster_bootstrap_rmse(
        y_test, {selected: p_test, naive_name: test_pred[naive_name], best_baseline: test_pred[best_baseline]},
        clusters, n_boot=n_boot, seed=seed, ref=naive_name)
    seg = ev.segment_metrics(test, tgt, "prediction", cfg.segment_col) if cfg.segment_col else None
    if seg is not None:
        seg.to_csv(out / "segment_metrics.csv", index=False)
    resid = ev.residual_diagnostics(test, tgt, "prediction", cfg.entity_cols, cfg.time_col)

    # ------------------------------------------------------------------ 6. prediction intervals
    abs_res = np.abs(oof[selected][covered] - y_dev[covered].to_numpy())
    segs_dev = dev[cfg.segment_col].to_numpy()[covered] if cfg.segment_col else None
    segs_test = test[cfg.segment_col].to_numpy() if cfg.segment_col else None
    hw = ev.conformal_halfwidths(abs_res, segs_dev, cfg.interval_alpha)
    lo, hi = ev.apply_intervals(p_test, segs_test, hw)
    test["lower"], test["upper"] = lo, hi
    intervals = ev.interval_report(y_test, lo, hi, segs_test)

    # ------------------------------------------------------------------ 7. interpretability & ablation
    grp_imp = ev.permutation_importance_groups(final, X_test, y_test, spec.groups, n_repeats=10, seed=seed)
    feat_imp = ev.permutation_importance_groups(final, X_test, y_test, {c: [c] for c in spec.all}, n_repeats=5, seed=seed)
    grp_imp.to_csv(out / "importance_groups.csv", index=False)
    feat_imp.to_csv(out / "importance_features.csv", index=False)

    full_rmse = ev.rmse(y_test, p_test)
    abl_rows = []
    for g, cols in spec.groups.items():
        num = [c for c in spec.numeric if c not in cols]
        cat = [c for c in spec.categorical if c not in cols]
        m = factory(num, cat).fit(dev[num + cat], y_dev)
        r = ev.rmse(y_test, m.predict(test[num + cat]))
        abl_rows.append({"dropped_group": g, "n_features": len(cols), "Test_RMSE_without": r,
                         "delta_RMSE": r - full_rmse})
    ablation = pd.DataFrame(abl_rows).sort_values("delta_RMSE", ascending=False).reset_index(drop=True)
    ablation.to_csv(out / "ablation.csv", index=False)

    # ------------------------------------------------------------------ 8. reliability checks
    gk = GroupKFold(n_splits=5)
    sp_rows = []
    for i, (tr, va) in enumerate(gk.split(X_dev, y_dev, groups=dev[cfg.group_col])):
        m = factory(spec.numeric, spec.categorical).fit(X_dev.iloc[tr], y_dev.iloc[tr])
        sp_rows.append({"fold": i + 1, "held_out_groups": int(dev.iloc[va][cfg.group_col].nunique()),
                        "RMSE": ev.rmse(y_dev.iloc[va], m.predict(X_dev.iloc[va]))})
    spatial = pd.DataFrame(sp_rows)
    spatial.to_csv(out / "spatial_cv.csv", index=False)

    drift = ev.drift_table(dev, test, spec.numeric)
    drift.to_csv(out / "drift_psi.csv", index=False)
    noise = ev.noise_robustness(final, X_test, y_test, X_dev, spec.numeric, seed=seed)
    miss = ev.missing_robustness(final, X_test, y_test, spec.numeric, seed=seed)
    noise.to_csv(out / "robustness_noise.csv", index=False)
    miss.to_csv(out / "robustness_missing.csv", index=False)

    # ------------------------------------------------------------------ 9. persist & plot
    test[[*cfg.entity_cols, cfg.time_col, tgt, "prediction", "lower", "upper", "error"]].to_csv(
        out / "test_predictions.csv", index=False)
    joblib.dump({"model": final, "features": spec, "config": cfg.name, "selected": selected}, out / "model.joblib")

    fig = out / "figures"
    periods = sorted(dev[cfg.time_col].unique().tolist() + test[cfg.time_col].unique().tolist())
    pl.plot_eda(df, cfg, fig / "eda.png")
    pl.plot_cv_scheme(fig / "cv_scheme.png", periods, cfg.test_periods, cfg.cv_folds, cfg.cv_block)
    pl.plot_model_comparison(table, fig / "model_comparison.png", cfg.target_unit)
    pl.plot_actual_vs_pred(test, cfg, fig / "actual_vs_pred.png")
    pl.plot_residuals(test, cfg, fig / "residuals.png")
    pl.plot_importance(grp_imp, fig / "importance_groups.png", cfg.target_unit)
    pl.plot_ablation(ablation, fig / "ablation.png", cfg.target_unit)
    pl.plot_robustness(noise, miss, fig / "robustness.png", cfg.target_unit)
    pl.plot_intervals(test, cfg, fig / "intervals.png")

    summary = {
        "scenario": cfg.name, "title": cfg.title, "target": tgt, "unit": cfg.target_unit,
        "n_rows_raw": int(len(raw)), "n_rows_model": int(len(df)), "n_entities": n_entities,
        "warmup_rows_dropped": int(dropped), "missing_share_%": float(raw.isna().mean().mean() * 100),
        "n_features_numeric": len(spec.numeric), "n_features_categorical": len(spec.categorical),
        "split": split_info, "selected_model": selected, "best_baseline": best_baseline,
        "best_params": {k: {a: (float(b) if isinstance(b, (np.floating, float)) else b) for a, b in v.items()}
                        for k, v in best_params.items()},
        "test_metrics": metrics, "bootstrap": boot, "intervals": intervals,
        "interval_halfwidths": hw, "residual_diagnostics": resid,
        "spatial_cv_rmse_mean": float(spatial["RMSE"].mean()), "spatial_cv_rmse_std": float(spatial["RMSE"].std()),
        "temporal_cv_rmse": float(table.loc[table["Model"] == selected, "CV_RMSE"].iloc[0]),
        "skill_vs_naive": metrics["skill_vs_naive"], "interval_coverage": intervals["coverage"],
        "n_features_psi_major": int((drift["PSI"] > 0.25).sum()), "n_features_psi_moderate": int(((drift["PSI"] > 0.10) & (drift["PSI"] <= 0.25)).sum()),
        "feature_groups": spec.groups, "runtime_s": round(time.time() - t0, 1),
    }
    with open(out / "summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=_jsonable)
    _log(f"[{cfg.name}] done in {summary['runtime_s']}s -> {out}", verbose)
    return summary
