"""Registry of ready-made scenarios (config + data generator).

To add a new agribusiness scenario: create a ``ScenarioConfig``, point it at a
data loader returning a tidy panel DataFrame, and register it below.
"""
from __future__ import annotations

from typing import Callable, Dict, Tuple

import pandas as pd

from .config import ScenarioConfig
from .synthetic import (derive_crop_features, derive_dairy_features,
                        generate_crop_yield, generate_dairy_milk)

CROP_YIELD = ScenarioConfig(
    name="crop_yield",
    title="Seasonal crop yield forecasting (region x crop x year)",
    target="yield_t_ha",
    target_unit="t/ha",
    time_col="year",
    entity_cols=["region", "crop"],
    group_col="region",
    segment_col="crop",
    categorical=["crop", "agro_zone"],
    numeric=[
        # weather
        "rainfall_mm", "tmax_mean_c", "tmin_mean_c", "humidity_pct", "solar_rad_mj",
        "dry_spell_days", "heat_stress_days", "diurnal_range_c", "water_index_mm", "heat_dry_stress",
        # soil
        "soil_ph", "soil_oc_pct", "soil_n_kg_ha",
        # management
        "fert_n_kg_ha", "irrigated_frac", "hybrid_frac", "n_x_irrigation", "area_kha",
        # biotic stress & remote sensing
        "pest_index", "ndvi_peak",
        # location
        "elevation_m",
    ],
    feature_groups={
        "weather": ["rainfall_mm", "tmax_mean_c", "tmin_mean_c", "humidity_pct", "solar_rad_mj",
                    "dry_spell_days", "heat_stress_days", "diurnal_range_c", "water_index_mm", "heat_dry_stress"],
        "soil": ["soil_ph", "soil_oc_pct", "soil_n_kg_ha"],
        "management": ["fert_n_kg_ha", "irrigated_frac", "hybrid_frac", "n_x_irrigation", "area_kha"],
        "biotic_stress": ["pest_index"],
        "remote_sensing": ["ndvi_peak"],
        "location": ["elevation_m", "agro_zone"],
        "crop_type": ["crop"],
    },
    lags=[1, 2],
    rolling_windows=[3],
    anomaly_cols=["rainfall_mm", "tmax_mean_c"],
    derive=derive_crop_features,
    test_periods=3, cv_folds=4, cv_block=2,
)

DAIRY_MILK = ScenarioConfig(
    name="dairy_milk",
    title="Monthly milk yield forecasting (farm x month)",
    target="milk_l_per_cow_day",
    target_unit="L/cow/day",
    time_col="month_idx",
    entity_cols=["farm_id"],
    group_col="cluster",
    segment_col="breed",
    categorical=["breed", "housing", "cluster"],
    numeric=[
        "temp_c", "humidity_pct", "thi", "thi_excess",
        "conc_feed_kg", "green_fodder_kg", "dry_fodder_kg", "total_dm_feed_kg",
        "herd_size", "mean_dim", "avg_parity",
        "mastitis_rate", "vet_visits", "distance_to_market_km",
    ],
    feature_groups={
        "climate": ["temp_c", "humidity_pct", "thi", "thi_excess"],
        "nutrition": ["conc_feed_kg", "green_fodder_kg", "dry_fodder_kg", "total_dm_feed_kg"],
        "herd": ["herd_size", "mean_dim", "avg_parity"],
        "health": ["mastitis_rate", "vet_visits"],
        "farm_profile": ["distance_to_market_km", "breed", "housing", "cluster"],
    },
    lags=[1, 2, 3],
    rolling_windows=[3, 6],
    anomaly_cols=[],
    cyclical={"month": 12},
    derive=derive_dairy_features,
    test_periods=12, cv_folds=4, cv_block=6,
)

SCENARIOS: Dict[str, Tuple[ScenarioConfig, Callable[[int], pd.DataFrame]]] = {
    "crop_yield": (CROP_YIELD, lambda seed: generate_crop_yield(seed=seed)),
    "dairy_milk": (DAIRY_MILK, lambda seed: generate_dairy_milk(seed=seed)),
}
