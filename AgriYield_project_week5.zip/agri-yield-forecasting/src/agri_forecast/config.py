"""Scenario configuration.

A *scenario* describes one forecasting problem (crop yield, milk yield, input
demand, ...). Everything scenario-specific lives in a ``ScenarioConfig``; the
rest of the framework (feature engineering, splitting, model selection,
evaluation, reliability checks) is generic and never needs editing.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import pandas as pd


@dataclass
class ScenarioConfig:
    # --- identity -----------------------------------------------------------
    name: str                       # short slug, used for output folders
    title: str                      # human readable title
    target: str                     # column to forecast
    target_unit: str                # e.g. "t/ha"

    # --- panel structure ----------------------------------------------------
    time_col: str                   # ordinal integer time index (year, month_idx, ...)
    entity_cols: List[str]          # columns that identify ONE series (for lags)
    group_col: str                  # spatial grouping used for group-wise CV
    segment_col: Optional[str]      # reporting segment (crop, breed, product, ...)

    # --- raw model inputs ---------------------------------------------------
    categorical: List[str]
    numeric: List[str]              # raw + derived numeric inputs (not lag features)
    feature_groups: Dict[str, List[str]]

    # --- feature engineering switches --------------------------------------
    lags: List[int] = field(default_factory=lambda: [1, 2])
    rolling_windows: List[int] = field(default_factory=lambda: [3])
    anomaly_cols: List[str] = field(default_factory=list)
    cyclical: Dict[str, int] = field(default_factory=dict)   # {"month": 12}
    derive: Optional[Callable[[pd.DataFrame], pd.DataFrame]] = None

    # --- validation design --------------------------------------------------
    test_periods: int = 3           # most recent periods held out as final test
    cv_folds: int = 4               # expanding-window folds on the development set
    cv_block: int = 2               # periods per validation block
    interval_alpha: float = 0.10    # 90 % prediction intervals
