"""Publication-quality figures (colour-blind-safe palette)."""
from __future__ import annotations
import matplotlib
matplotlib.use("Agg")
import matplotlib.ticker
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

C = dict(blue="#0072B2", orange="#E69F00", green="#009E73", red="#D55E00", purple="#CC79A7", sky="#56B4E9", grey="#6B7280")
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "axes.titlesize": 11, "figure.dpi": 130, "savefig.bbox": "tight",
                     "axes.grid": True, "grid.alpha": .25})


def _save(fig, path):
    fig.savefig(path, dpi=200); plt.close(fig)


def fig_target_overview(df, sc, path):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    key = sc.entity_cols[-1] if sc.name == "crop_yield" else "breed"
    pal = list(C.values())
    for i, (k, g) in enumerate(df.groupby(key)):
        m = g.groupby(sc.time_col)[sc.target].mean()
        ax[0].plot(m.index, m.values, label=str(k), color=pal[i % len(pal)], lw=1.8)
    ax[0].set(title=f"Mean {sc.target} over time", xlabel=sc.time_col, ylabel=sc.target_unit)
    ax[0].legend(frameon=False, fontsize=8, ncol=2)
    ax[1].hist(df[sc.target], bins=40, color=C["blue"], alpha=.85)
    ax[1].set(title="Target distribution", xlabel=sc.target_unit, ylabel="records")
    fig.tight_layout(); _save(fig, path)


def fig_correlation(df, cols, target, path, top=14):
    cor = df[cols + [target]].corr(numeric_only=True)[target].drop(target).sort_values()
    cor = pd.concat([cor.head(top // 2), cor.tail(top // 2)]).drop_duplicates()
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    ax.barh(cor.index, cor.values, color=[C["blue"] if v > 0 else C["red"] for v in cor.values])
    ax.axvline(0, color="k", lw=.8)
    ax.set(title=f"Pearson correlation with target ({target})", xlabel="correlation")
    fig.tight_layout(); _save(fig, path)


def fig_model_comparison(res: pd.DataFrame, path):
    res = res.sort_values("RMSE")
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
    cols = [C["grey"] if "Baseline" in n else C["blue"] for n in res.index]
    ax[0].barh(res.index, res["RMSE"], color=cols); ax[0].invert_yaxis()
    ax[0].set(title="Hold-out test RMSE (lower is better)", xlabel="RMSE")
    ax[1].barh(res.index, res["R2"], color=cols); ax[1].invert_yaxis()
    ax[1].set(title="Hold-out test R² (higher is better)", xlabel="R²")
    for a, c in zip(ax, ["RMSE", "R2"]):
        for i, v in enumerate(res[c]):
            a.text(v, i, f" {v:.2f}", va="center", fontsize=8)
    fig.tight_layout(); _save(fig, path)


def fig_pred_vs_actual(pred: pd.DataFrame, unit, path):
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    lim = [min(pred.y_true.min(), pred.y_pred.min()), max(pred.y_true.max(), pred.y_pred.max())]
    ax[0].scatter(pred.y_true, pred.y_pred, s=14, alpha=.6, color=C["blue"], edgecolor="none")
    ax[0].plot(lim, lim, color=C["red"], lw=1.2, ls="--", label="perfect prediction")
    ax[0].set(title="Predicted vs actual (test)", xlabel=f"actual ({unit})", ylabel=f"predicted ({unit})")
    ax[0].legend(frameon=False)
    res = pred.y_pred - pred.y_true
    ax[1].hist(res, bins=35, color=C["green"], alpha=.85)
    ax[1].axvline(0, color="k", lw=.8)
    ax[1].set(title="Residual distribution", xlabel="prediction error", ylabel="records")
    fig.tight_layout(); _save(fig, path)


def fig_importance(imp: pd.DataFrame, path, top=15):
    d = imp.head(top).iloc[::-1]
    fig, ax = plt.subplots(figsize=(6.8, 4.8))
    ax.barh(d.index, d["mean"], xerr=d["std"], color=C["blue"], ecolor=C["grey"], capsize=2)
    ax.set(title="Permutation importance (increase in test RMSE)", xlabel="Δ RMSE when feature is shuffled")
    fig.tight_layout(); _save(fig, path)


def fig_ablation(abl: pd.DataFrame, base_rmse: float, path):
    d = abl.sort_values("RMSE")
    fig, ax = plt.subplots(figsize=(6.8, 3.8))
    ax.barh(d.index, d["RMSE"], color=C["orange"])
    ax.axvline(base_rmse, color=C["blue"], lw=1.6, label=f"all features ({base_rmse:.2f})")
    ax.set(title="Feature-group ablation (test RMSE after removing group)", xlabel="RMSE")
    ax.legend(frameon=False)
    fig.tight_layout(); _save(fig, path)


def fig_intervals(pred: pd.DataFrame, time_col, unit, cov, path):
    g = pred.groupby(time_col).agg(y=("y_true", "mean"), p=("y_pred", "mean"), lo=("lo", "mean"), hi=("hi", "mean"))
    fig, ax = plt.subplots(figsize=(7, 3.6))
    ax.fill_between(g.index, g.lo, g.hi, color=C["sky"], alpha=.4, label=f"90% conformal interval (coverage {cov:.0%})")
    ax.plot(g.index, g.p, color=C["blue"], lw=2, marker="o", label="forecast")
    ax.plot(g.index, g.y, color=C["red"], lw=2, marker="s", label="actual")
    ax.set(title="Test-period forecasts with uncertainty (average over entities)", xlabel=time_col, ylabel=unit)
    ax.legend(frameon=False, fontsize=8)
    ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True))
    fig.tight_layout(); _save(fig, path)


def fig_group_error(df: pd.DataFrame, name, path):
    d = df.sort_values("RMSE")
    fig, ax = plt.subplots(figsize=(6.5, max(3, .3 * len(d) + 1)))
    ax.barh(d.index.astype(str), d["RMSE"], color=C["purple"])
    ax.set(title=f"Test RMSE by {name}", xlabel="RMSE")
    fig.tight_layout(); _save(fig, path)


def fig_cv_folds(cv: pd.DataFrame, path):
    fig, ax = plt.subplots(figsize=(7, 3.6))
    w = .8 / len(cv.columns)
    for i, c in enumerate(cv.columns):
        ax.bar(np.arange(len(cv)) + i * w, cv[c], width=w, label=c)
    ax.set_xticks(np.arange(len(cv)) + .4 - w / 2); ax.set_xticklabels(cv.index)
    ax.set(title="Forward-chaining CV: RMSE per validation fold", xlabel="validation fold", ylabel="RMSE")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(); _save(fig, path)
