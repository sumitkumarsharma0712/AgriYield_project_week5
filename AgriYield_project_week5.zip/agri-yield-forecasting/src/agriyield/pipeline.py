"""End-to-end orchestration: data -> features -> split -> tune -> evaluate -> explain -> persist."""
from __future__ import annotations
import json, time
from pathlib import Path
from typing import Dict
import joblib
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.model_selection import GroupKFold

from . import plots
from .config import SCENARIOS, Scenario
from .data_generator import load_data
from .evaluate import (conformal_interval, drift_table, interval_coverage, metrics_by,
                       regression_metrics, skill_score)
from .features import build_features
from .models import (ExpandingWindowSplit, build_ensemble, build_pipeline, model_zoo, tune_model)


def split_columns(df, cols):
    num = [c for c in cols if pd.api.types.is_numeric_dtype(df[c])]
    cat = [c for c in cols if c not in num]
    return num, cat


def run(scenario: str = "crop_yield", out_dir: str = "outputs", data_path: str | None = None,
        n_iter: int = 15, seed: int = 42, verbose: bool = True) -> Dict:
    t0 = time.time()
    sc: Scenario = SCENARIOS[scenario]
    out = Path(out_dir) / scenario
    (out / "figures").mkdir(parents=True, exist_ok=True)
    log = (lambda *a: print(*a, flush=True)) if verbose else (lambda *a: None)

    # 1 ---------------- data
    raw = load_data(scenario, data_path)
    raw.to_csv(Path(out) / "dataset.csv", index=False)
    df, groups = build_features(raw, sc)
    all_cols = [c for g in groups.values() for c in g]
    num_cols, cat_cols = split_columns(df, all_cols)
    log(f"[{scenario}] rows={len(df)}  features={len(all_cols)} (numeric {len(num_cols)}, categorical {len(cat_cols)})")

    # 2 ---------------- chronological split (test period is never touched during tuning)
    dev_mask = (df[sc.time_col] <= sc.dev_end).values
    dev, test = df[dev_mask].reset_index(drop=True), df[~dev_mask].reset_index(drop=True)
    # first rows of each series have no lag: keep them (median imputer + indicator-free), but
    # drop rows where lag1 is missing from *evaluation* so metrics reflect true one-step-ahead forecasts
    lag1 = f"{sc.target}_lag1"
    test = test[test[lag1].notna()].reset_index(drop=True)
    X_dev, y_dev = dev[all_cols], dev[sc.target].values
    X_test, y_test = test[all_cols], test[sc.target].values
    cv = ExpandingWindowSplit(dev[sc.time_col].values, sc.cv_folds, sc.cv_block)
    log(f"  dev={len(dev)} test={len(test)}  CV validation blocks={[list(map(int, b)) for b in cv.blocks]}")

    results, preds, cv_scores, best_params = {}, {}, {}, {}

    # 3 ---------------- naive baselines
    base_naive = test[lag1].values
    base_roll = test[f"{sc.target}_roll{sc.roll_window}"].values
    ent_mean = dev.groupby(sc.entity_cols)[sc.target].mean()
    base_ent = test.set_index(sc.entity_cols).index.map(ent_mean).values
    for n, p in [("Baseline: last period", base_naive), (f"Baseline: {sc.roll_window}-period mean", base_roll),
                 ("Baseline: entity mean", base_ent)]:
        p = np.where(np.isnan(p), np.nanmean(y_dev), p)
        results[n] = regression_metrics(y_test, p); preds[n] = p
    base_rmse = results["Baseline: last period"]["RMSE"]

    # 4 ---------------- tune + evaluate ML models
    zoo = model_zoo(seed)
    fitted: Dict[str, object] = {}
    oof: Dict[str, np.ndarray] = {}
    for name, (est, space, scale) in zoo.items():
        params, cv_rmse = tune_model(name, est, space, scale, num_cols, cat_cols, X_dev, y_dev, cv, n_iter, seed)
        best_params[name] = {k: (v.item() if hasattr(v, "item") else v) for k, v in params.items()}
        pipe_cv = build_pipeline(est, scale, num_cols, cat_cols, params)
        fold_rmse, o = [], np.full(len(dev), np.nan)
        for tr, va in cv.split():
            m = build_pipeline(est, scale, num_cols, cat_cols, params).fit(X_dev.iloc[tr], y_dev[tr])
            p = m.predict(X_dev.iloc[va]); o[va] = p
            fold_rmse.append(np.sqrt(np.mean((p - y_dev[va]) ** 2)))
        cv_scores[name] = fold_rmse; oof[name] = o
        final = build_pipeline(est, scale, num_cols, cat_cols, params).fit(X_dev, y_dev)   # refit on all dev data
        fitted[name] = final
        preds[name] = final.predict(X_test)
        results[name] = regression_metrics(y_test, preds[name]); results[name]["CV_RMSE"] = float(np.mean(fold_rmse))
        log(f"  {name:<17} CV-RMSE={np.mean(fold_rmse):.3f}  TEST-RMSE={results[name]['RMSE']:.3f}  R2={results[name]['R2']:.3f}")

    # 5 ---------------- ensemble of the top-2 models by CV
    top2 = sorted(cv_scores, key=lambda k: np.mean(cv_scores[k]))[:2]
    ens = build_ensemble({k: build_pipeline(zoo[k][0], zoo[k][2], num_cols, cat_cols, best_params[k]) for k in top2}).fit(X_dev, y_dev)
    fitted["Ensemble"] = ens
    preds["Ensemble"] = ens.predict(X_test)
    results["Ensemble"] = regression_metrics(y_test, preds["Ensemble"])
    oof["Ensemble"] = np.mean([oof[k] for k in top2], axis=0)      # NaN where a row was never validated
    results["Ensemble"]["CV_RMSE"] = float(np.sqrt(np.nanmean((oof["Ensemble"] - y_dev) ** 2)))
    log(f"  Ensemble({'+'.join(top2)}) TEST-RMSE={results['Ensemble']['RMSE']:.3f} R2={results['Ensemble']['R2']:.3f}")

    res_df = pd.DataFrame(results).T
    res_df["Skill_vs_naive"] = [skill_score(r, base_rmse) for r in res_df["RMSE"]]
    ml_names = list(zoo) + ["Ensemble"]
    champion = res_df.loc[ml_names, "CV_RMSE"].astype(float).idxmin()      # chosen on CV, not on test
    log(f"  Champion (selected by CV): {champion}")
    champ = fitted[champion]

    # 6 ---------------- uncertainty: split-conformal intervals from out-of-fold residuals
    mask = ~np.isnan(oof[champion])
    lo, hi, qhat = conformal_interval(y_dev[mask] - oof[champion][mask], preds[champion], alpha=0.10)
    coverage = interval_coverage(y_test, lo, hi)

    pred_df = test[sc.entity_cols + [sc.time_col]].copy()
    pred_df["y_true"], pred_df["y_pred"], pred_df["lo"], pred_df["hi"] = y_test, preds[champion], lo, hi
    pred_df["abs_err"] = (pred_df.y_true - pred_df.y_pred).abs()
    pred_df.to_csv(out / "test_predictions.csv", index=False)

    by_group = metrics_by(pred_df, sc.group_col)
    by_time = metrics_by(pred_df, sc.time_col)
    by_extra = metrics_by(pred_df, "crop") if "crop" in pred_df else None

    # 7 ---------------- explainability: permutation importance on the hold-out set
    pi = permutation_importance(champ, X_test, y_test, n_repeats=10, random_state=seed,
                                scoring="neg_root_mean_squared_error", n_jobs=1)
    imp = pd.DataFrame({"mean": pi.importances_mean, "std": pi.importances_std}, index=all_cols).sort_values("mean", ascending=False)
    imp.to_csv(out / "permutation_importance.csv")

    # 8 ---------------- feature-group ablation (same hyper-parameters, refit without a group)
    est, _, scale = zoo[champion] if champion in zoo else zoo[top2[0]]
    abl_params = best_params[champion] if champion in best_params else best_params[top2[0]]
    abl = {}
    for g, cols in groups.items():
        keep = [c for c in all_cols if c not in cols]
        n_, c_ = split_columns(df, keep)
        m = build_pipeline(est, scale, n_, c_, abl_params).fit(dev[keep], y_dev)
        abl[f"- {g}"] = regression_metrics(y_test, m.predict(test[keep]))
    abl_df = pd.DataFrame(abl).T

    # 9 ---------------- spatial robustness: leave-entity-out CV (unseen districts / farms)
    gkf = GroupKFold(n_splits=5)
    est_s, _, scale_s = zoo[top2[0]]
    sp = []
    for tr, va in gkf.split(dev, y_dev, groups=dev[sc.group_col]):
        m = build_pipeline(est_s, scale_s, num_cols, cat_cols, best_params[top2[0]]).fit(X_dev.iloc[tr], y_dev[tr])
        sp.append(regression_metrics(y_dev[va], m.predict(X_dev.iloc[va])))
    spatial = pd.DataFrame(sp).mean().to_dict()

    # 10 --------------- drift between dev and test inputs
    num_raw = [c for c in num_cols if c not in groups["history"]]
    drift = drift_table(dev, test, num_raw)

    # 11 --------------- figures
    fg = out / "figures"
    plots.fig_target_overview(raw, sc, fg / "01_target_overview.png")
    plots.fig_correlation(df, [c for c in num_cols if c != sc.target and c in df.columns], sc.target, fg / "02_correlation.png")
    plots.fig_model_comparison(res_df[["RMSE", "R2"]].astype(float), fg / "03_model_comparison.png")
    plots.fig_pred_vs_actual(pred_df, sc.target_unit, fg / "04_pred_vs_actual.png")
    plots.fig_importance(imp, fg / "05_importance.png")
    plots.fig_ablation(abl_df[["RMSE"]], results[champion]["RMSE"], fg / "06_ablation.png")
    plots.fig_intervals(pred_df, sc.time_col, sc.target_unit, coverage, fg / "07_intervals.png")
    plots.fig_group_error(by_group, sc.group_col, fg / "08_error_by_group.png")
    cvdf = pd.DataFrame({k: v for k, v in cv_scores.items()}, index=[f"F{i+1}" for i in range(sc.cv_folds)])
    plots.fig_cv_folds(cvdf, fg / "09_cv_folds.png")

    # 12 --------------- persist artefacts
    res_df.round(4).to_csv(out / "model_comparison.csv")
    by_group.round(4).to_csv(out / f"metrics_by_{sc.group_col}.csv")
    by_time.round(4).to_csv(out / f"metrics_by_{sc.time_col}.csv")
    if by_extra is not None: by_extra.round(4).to_csv(out / "metrics_by_crop.csv")
    abl_df.round(4).to_csv(out / "ablation.csv"); drift.round(4).to_csv(out / "drift_psi.csv", index=False)
    cvdf.round(4).to_csv(out / "cv_fold_rmse.csv")
    joblib.dump({"model": champ, "features": all_cols, "scenario": sc.name, "conformal_halfwidth": qhat}, out / "champion_model.joblib")
    summary = dict(scenario=sc.name, rows=len(df), n_features=len(all_cols), dev_rows=len(dev), test_rows=len(test),
                   champion=champion, ensemble_members=top2, best_params=best_params,
                   test_metrics=results[champion], baseline_rmse=base_rmse,
                   skill_vs_naive=skill_score(results[champion]["RMSE"], base_rmse),
                   interval_coverage_90=coverage, interval_halfwidth=qhat, spatial_cv=spatial,
                   top_features=imp.head(10)["mean"].round(4).to_dict(), runtime_s=round(time.time() - t0, 1))
    json.dump(summary, open(out / "summary.json", "w"), indent=2, default=float)
    log(f"  coverage(90%)={coverage:.3f}  spatial-CV RMSE={spatial['RMSE']:.3f}  runtime={summary['runtime_s']}s")
    return summary
