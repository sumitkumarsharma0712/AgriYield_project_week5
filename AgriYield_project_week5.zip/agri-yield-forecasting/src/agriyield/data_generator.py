"""Synthetic but agronomically-motivated data generators.

IMPORTANT: the data are simulated (no public panel with every variable could be
redistributed here). The generators encode realistic agronomic relationships
(water-use response, heat stress at flowering, fertiliser response with
diminishing returns, pest damage, technology trend, district effects), so the
framework can be exercised end-to-end. Real data in the same schema can be
dropped in through ``load_data``; nothing else needs to change.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

DISTRICTS = {
    # name: (mean monsoon rain mm, soil quality 0-1, irrigated fraction base, mean temp C)
    "Nagpur": (950, 0.75, 0.30, 27.5), "Wardha": (980, 0.80, 0.28, 27.2),
    "Amravati": (880, 0.72, 0.25, 27.0), "Yavatmal": (930, 0.62, 0.15, 26.8),
    "Akola": (780, 0.70, 0.22, 27.4), "Buldhana": (740, 0.66, 0.20, 27.1),
    "Chandrapur": (1150, 0.60, 0.35, 27.8), "Bhandara": (1250, 0.68, 0.55, 27.0),
    "Gondia": (1300, 0.64, 0.60, 26.6), "Washim": (800, 0.65, 0.18, 26.9),
    "Nashik": (700, 0.78, 0.45, 25.5), "Pune": (650, 0.82, 0.50, 25.0),
    "Aurangabad": (620, 0.68, 0.30, 26.5), "Latur": (700, 0.74, 0.32, 26.8),
}
CROPS = {
    # base yield q/ha, optimal water mm, heat threshold C at flowering, fert N optimum kg/ha, sowing doy
    "Cotton": (15.0, 850, 36.0, 100, 160), "Soybean": (13.0, 700, 34.0, 40, 175),
    "Rice": (30.0, 1100, 35.0, 110, 170), "Wheat": (32.0, 450, 32.0, 120, 320),
    "Tur": (9.0, 650, 35.0, 25, 170),
}
DROUGHT_YEARS = {2009: 0.70, 2012: 0.80, 2014: 0.75, 2015: 0.72, 2018: 0.82, 2022: 0.85}
FLOOD_YEARS = {2006: 1.25, 2013: 1.20, 2019: 1.22, 2020: 1.18}


def generate_crop_data(start=2005, end=2023, seed=42, missing_rate=0.03) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    years = np.arange(start, end + 1)
    year_shock = {y: DROUGHT_YEARS.get(y, FLOOD_YEARS.get(y, 1.0)) * rng.normal(1, 0.06) for y in years}
    year_heat = {y: rng.normal(0, 1.1) + 0.05 * (y - start) for y in years}   # warming trend
    rows = []
    soil = {d: dict(ph=rng.normal(7.3, 0.35), oc=0.35 + 0.6 * q * rng.uniform(.7, 1.2),
                    n=150 + 150 * q + rng.normal(0, 12), p=12 + 12 * q + rng.normal(0, 2),
                    k=230 + 200 * q + rng.normal(0, 20), whc=14 + 14 * q + rng.normal(0, 1.2))
            for d, (_, q, _, _) in DISTRICTS.items()}
    prev_ndvi = {}
    for d, (rain_mu, q, irr0, tmean0) in DISTRICTS.items():
        s = soil[d]
        d_eff = rng.normal(0, 0.05)
        for y in years:
            rain = max(250, rain_mu * year_shock[y] * rng.normal(1, 0.10))
            rain_days = int(np.clip(rain / 14 + rng.normal(0, 4), 25, 90))
            dry_spell = int(np.clip(28 - rain / 70 + rng.normal(0, 4) + (6 if y in DROUGHT_YEARS else 0), 3, 45))
            tmean = tmean0 + 0.5 * year_heat[y] * 0.4 + rng.normal(0, 0.5)
            hum = np.clip(58 + rain / 40 + rng.normal(0, 4), 40, 92)
            solar = np.clip(19.5 - rain / 400 + rng.normal(0, 0.9), 14, 24)
            irr = np.clip(irr0 + 0.01 * (y - start) + rng.normal(0, 0.03), 0.03, 0.9)
            for c, (base, opt_w, heat_thr, n_opt, sow) in CROPS.items():
                rabi = c == "Wheat"
                # water available to crop
                irr_c = np.clip(irr * rng.uniform(0.8, 1.2), 0, 1)
                eff_water = rain * (0.55 if rabi else 1.0) + irr_c * opt_w * 0.65
                w_ratio = eff_water / opt_w
                water_f = 1 - 0.85 * np.clip((w_ratio - 1.0) / 1.0, -1, 1) ** 2 if w_ratio < 1.0 else 1 - 0.25 * np.clip(w_ratio - 1.3, 0, 1) ** 2
                water_f = np.clip(water_f, 0.25, 1.05)
                tmax_fl = tmean + 7.5 + year_heat[y] * 0.5 + rng.normal(0, 1.0) + (1.5 if rabi else 0)
                heat_f = 1 - 0.07 * max(0, tmax_fl - heat_thr) ** 1.3
                dry_f = 1 - 0.006 * max(0, dry_spell - 12)
                fert = np.clip(n_opt * rng.uniform(0.5, 1.3) * (0.9 + 0.2 * q), 5, 220)
                fert_f = 0.75 + 0.25 * (1 - np.exp(-fert / (0.55 * n_opt))) / (1 - np.exp(-1 / .55)) \
                    - 0.0004 * max(0, fert - 1.35 * n_opt) ** 1.2
                soil_f = 0.7 + 0.45 * q + 0.04 * (s["oc"] - 0.6)
                pest = np.clip(rng.beta(2, 6) + 0.35 * (hum - 65) / 30 + (0.1 if rain > 1.2 * rain_mu else 0), 0, 1)
                pest_f = 1 - 0.22 * pest
                variety = rng.choice(["Local", "Improved", "Hybrid"], p=[.25, .5, .25] if y < 2013 else [.12, .48, .40])
                var_f = {"Local": 0.92, "Improved": 1.0, "Hybrid": 1.10}[variety]
                trend = 1 + 0.011 * (y - start)
                sowing = int(sow + rng.normal(0, 7) + (6 if y in DROUGHT_YEARS else 0))
                sow_f = 1 - 0.0025 * abs(sowing - sow)
                y_det = base * trend * water_f * heat_f * dry_f * fert_f * soil_f * pest_f * var_f * sow_f * (1 + d_eff)
                yld = max(1.0, y_det * rng.lognormal(0, 0.07))
                ndvi = np.clip(0.35 + 0.5 * (yld / (base * 1.4)) + rng.normal(0, 0.05), 0.2, 0.92)
                rows.append(dict(
                    year=y, district=d, crop=c, yield_q_ha=round(yld, 2),
                    monsoon_rain_mm=round(rain, 1), rain_days=rain_days, max_dry_spell_days=dry_spell,
                    tmean_c=round(tmean, 2), tmax_flowering_c=round(tmax_fl, 2), humidity_pct=round(hum, 1),
                    solar_mj_m2=round(solar, 2), soil_ph=round(s["ph"], 2), soil_oc_pct=round(s["oc"], 2),
                    soil_n_kg_ha=round(s["n"], 1), soil_p_kg_ha=round(s["p"], 1), soil_k_kg_ha=round(s["k"], 1),
                    water_holding_pct=round(s["whc"], 1), irrigated_frac=round(irr_c, 3),
                    fert_n_kg_ha=round(fert, 1), seed_rate_kg_ha=round(rng.normal(25 if c != "Cotton" else 3, 2), 1),
                    sowing_doy=sowing, variety_type=variety, pest_index=round(pest, 3), ndvi_peak=round(ndvi, 3)))
    df = pd.DataFrame(rows)
    return _inject_missing(df, ["humidity_pct", "soil_ph", "pest_index", "ndvi_peak", "solar_mj_m2"], missing_rate, rng)


def generate_dairy_data(n_farms=40, n_months=60, seed=7, missing_rate=0.03) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    breeds = {"HF_cross": 15.0, "Jersey_cross": 11.5, "Gir": 6.5, "Sahiwal_cross": 7.5}
    regions = ["Vidarbha", "Marathwada", "WestMaha"]
    farms = {f"F{i:03d}": dict(breed=rng.choice(list(breeds), p=[.35, .25, .2, .2]),
                               region=rng.choice(regions), herd=int(rng.integers(8, 60)),
                               eff=rng.normal(0, .08)) for i in range(n_farms)}
    rows = []
    for fid, f in farms.items():
        for t in range(1, n_months + 1):
            m = (t - 1) % 12 + 1
            seasonal = np.sin(2 * np.pi * (m - 4) / 12)
            temp = 27 + 8 * seasonal + rng.normal(0, 1.5) + 0.02 * t / 12
            rh = np.clip(55 + 25 * np.sin(2 * np.pi * (m - 7) / 12) + rng.normal(0, 6), 25, 95)
            rain = max(0, 100 * (1 + np.sin(2 * np.pi * (m - 7) / 12)) * rng.gamma(2, .5) * (m in (6, 7, 8, 9)))
            thi = 0.8 * temp + rh / 100 * (temp - 14.4) + 46.4
            conc = np.clip(rng.normal(3.0 if f["breed"] in ("HF_cross", "Jersey_cross") else 1.8, .5), .5, 6)
            green = np.clip(rng.normal(16, 4) + 0.01 * rain, 2, 35)
            dry = np.clip(rng.normal(5, 1.2), 1, 10)
            lact = np.clip(rng.normal(5.5, 1.5) + 0.3 * np.sin(t / 5), 1, 10)
            health = np.clip(rng.normal(8, 1.2) - 0.15 * max(0, thi - 78), 3, 10)
            vet = int(rng.poisson(1.2 + 0.3 * (thi > 78)))
            curve = 1.25 * (lact / 3.0) * np.exp(1 - lact / 3.0) if lact > 0 else 1
            curve = 0.6 + 0.45 * curve
            heat = 1 - 0.035 * max(0, thi - 72) ** 1.1 / 3
            feed = 0.75 + 0.25 * (1 - np.exp(-(conc * 1.2 + green * .05 + dry * .1) / 3))
            milk = breeds[f["breed"]] * curve * heat * feed * (0.85 + 0.015 * health) * (1 + f["eff"]) * rng.lognormal(0, .05)
            rows.append(dict(month_idx=t, farm_id=fid, breed=f["breed"], region=f["region"], herd_size=f["herd"],
                             temp_c=round(temp, 2), humidity_pct=round(rh, 1), rainfall_mm=round(rain, 1),
                             concentrate_kg=round(conc, 2), green_fodder_kg=round(green, 1), dry_fodder_kg=round(dry, 2),
                             avg_lactation_month=round(lact, 2), health_score=round(health, 2), vet_visits=vet,
                             milk_l_per_cow_day=round(max(.5, milk), 2)))
    df = pd.DataFrame(rows)
    return _inject_missing(df, ["humidity_pct", "health_score", "green_fodder_kg"], missing_rate, rng)


def _inject_missing(df, cols, rate, rng):
    df = df.copy()
    for c in cols:
        mask = rng.random(len(df)) < rate
        df.loc[mask, c] = np.nan
    return df


def load_data(scenario_name: str, path: str | None = None, seed: int | None = None) -> pd.DataFrame:
    """Load real data from CSV if ``path`` is given, otherwise simulate."""
    if path:
        return pd.read_csv(path)
    if scenario_name == "crop_yield":
        return generate_crop_data(seed=seed or 42)
    if scenario_name == "dairy_milk":
        return generate_dairy_data(seed=seed or 7)
    raise ValueError(f"Unknown scenario {scenario_name}")
