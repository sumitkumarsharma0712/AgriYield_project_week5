"""Scenario configuration.

The whole framework is driven by a ``Scenario`` object. To apply it to a new
agribusiness problem (a new crop, dairy output, input-demand forecasting ...)
you only declare *what* the target is, *which* column is time, *which* columns
identify an entity and *which* columns belong to which feature group.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class Scenario:
    name: str
    description: str
    target: str
    target_unit: str
    time_col: str
    entity_cols: List[str]            # columns that identify one time series
    group_col: str                    # column used for leave-group-out validation
    feature_groups: Dict[str, List[str]]
    dev_end: int                      # last period used for development (train+val)
    cv_folds: int = 4                 # expanding-window validation folds
    cv_block: int = 1                 # periods per validation fold
    lags: List[int] = field(default_factory=lambda: [1, 2])
    roll_window: int = 3
    date_hint: str = ""

    @property
    def raw_features(self) -> List[str]:
        cols: List[str] = []
        for v in self.feature_groups.values():
            cols += v
        return cols


CROP_YIELD = Scenario(
    name="crop_yield",
    description="District-level seasonal crop yield forecasting (Vidarbha / Maharashtra style panel).",
    target="yield_q_ha",
    target_unit="quintal/ha",
    time_col="year",
    entity_cols=["district", "crop"],
    group_col="district",
    feature_groups={
        "weather": ["monsoon_rain_mm", "rain_days", "max_dry_spell_days", "tmean_c",
                    "tmax_flowering_c", "humidity_pct", "solar_mj_m2"],
        "soil": ["soil_ph", "soil_oc_pct", "soil_n_kg_ha", "soil_p_kg_ha", "soil_k_kg_ha", "water_holding_pct"],
        "management": ["irrigated_frac", "fert_n_kg_ha", "seed_rate_kg_ha", "sowing_doy", "variety_type", "pest_index"],
        "remote_sensing": ["ndvi_peak"],
        "identity": ["district", "crop"],
    },
    dev_end=2020,
    cv_folds=4,
    cv_block=1,
)

DAIRY_MILK = Scenario(
    name="dairy_milk",
    description="Farm-level monthly milk yield forecasting (demonstrates framework transfer).",
    target="milk_l_per_cow_day",
    target_unit="litres/cow/day",
    time_col="month_idx",
    entity_cols=["farm_id"],
    group_col="farm_id",
    feature_groups={
        "weather": ["temp_c", "humidity_pct", "rainfall_mm"],
        "feeding": ["concentrate_kg", "green_fodder_kg", "dry_fodder_kg"],
        "herd": ["avg_lactation_month", "herd_size", "health_score", "vet_visits"],
        "identity": ["farm_id", "breed", "region"],
    },
    dev_end=48,
    cv_folds=4,
    cv_block=3,
    lags=[1, 2, 3],
    roll_window=3,
)

SCENARIOS = {s.name: s for s in (CROP_YIELD, DAIRY_MILK)}
