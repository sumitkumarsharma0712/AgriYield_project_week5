"""Feature engineering: generic (lags, rolling stats, anomalies) + scenario-specific."""
from __future__ import annotations
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
from .config import Scenario


def add_history_features(df: pd.DataFrame, sc: Scenario) -> Tuple[pd.DataFrame, List[str]]:
    """Lagged target and rolling mean built ONLY from strictly earlier periods (no leakage)."""
    df = df.sort_values(sc.entity_cols + [sc.time_col]).copy()
    g = df.groupby(sc.entity_cols, sort=False)[sc.target]
    new = []
    for L in sc.lags:
        c = f"{sc.target}_lag{L}"
        df[c] = g.shift(L)
        new.append(c)
    c = f"{sc.target}_roll{sc.roll_window}"
    df[c] = g.transform(lambda s: s.shift(1).rolling(sc.roll_window, min_periods=1).mean())
    new.append(c)
    c = f"{sc.target}_trend"      # change between the two most recent observations
    df[c] = df[f"{sc.target}_lag1"] - df[f"{sc.target}_lag2" if 2 in sc.lags else f"{sc.target}_lag1"]
    new.append(c)
    return df, new


def crop_domain_features(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    df = df.copy()
    df["rain_per_day"] = df["monsoon_rain_mm"] / df["rain_days"].clip(lower=1)
    df["water_supply_index"] = df["monsoon_rain_mm"] * (1 + df["irrigated_frac"]) * df["water_holding_pct"] / 20
    df["heat_stress_deg"] = (df["tmax_flowering_c"] - 33).clip(lower=0)
    df["dryspell_x_heat"] = df["max_dry_spell_days"] * df["heat_stress_deg"]
    df["npk_total"] = df["soil_n_kg_ha"] + df["soil_p_kg_ha"] * 2 + df["soil_k_kg_ha"] * 0.5
    df["n_applied_per_soil_n"] = df["fert_n_kg_ha"] / df["soil_n_kg_ha"].clip(lower=1)
    df["gdd_proxy"] = (df["tmean_c"] - 10).clip(lower=0) * 120
    new = ["rain_per_day", "water_supply_index", "heat_stress_deg", "dryspell_x_heat",
           "npk_total", "n_applied_per_soil_n", "gdd_proxy"]
    return df, new


def dairy_domain_features(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    df = df.copy()
    rh = df["humidity_pct"].fillna(df["humidity_pct"].median())
    df["thi"] = 0.8 * df["temp_c"] + rh / 100 * (df["temp_c"] - 14.4) + 46.4   # temperature-humidity index
    df["heat_stress_thi"] = (df["thi"] - 72).clip(lower=0)
    m = (df["month_idx"] - 1) % 12 + 1
    df["month_sin"] = np.sin(2 * np.pi * m / 12)
    df["month_cos"] = np.cos(2 * np.pi * m / 12)
    df["total_feed_kg"] = df["concentrate_kg"] + df["green_fodder_kg"] + df["dry_fodder_kg"]
    df["conc_share"] = df["concentrate_kg"] / df["total_feed_kg"].clip(lower=.1)
    df["lact_curve"] = df["avg_lactation_month"] * np.exp(-df["avg_lactation_month"] / 3.0)
    new = ["thi", "heat_stress_thi", "month_sin", "month_cos", "total_feed_kg", "conc_share", "lact_curve"]
    return df, new


DOMAIN = {"crop_yield": crop_domain_features, "dairy_milk": dairy_domain_features}


def build_features(df: pd.DataFrame, sc: Scenario) -> Tuple[pd.DataFrame, Dict[str, List[str]]]:
    """Return the engineered frame and the full ``feature group -> columns`` map."""
    df, lag_cols = add_history_features(df, sc)
    df, dom_cols = DOMAIN[sc.name](df)
    groups = {k: list(v) for k, v in sc.feature_groups.items()}
    groups["history"] = lag_cols
    groups["engineered"] = dom_cols
    return df, groups
